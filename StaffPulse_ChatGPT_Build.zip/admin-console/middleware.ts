import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Public routes
  if (pathname === '/login' || pathname === '/' || pathname.startsWith('/_next')) {
    return NextResponse.next();
  }

  // Client-side check happens in layout; middleware just redirects / → /login
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
