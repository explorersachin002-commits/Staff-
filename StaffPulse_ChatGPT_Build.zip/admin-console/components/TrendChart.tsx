'use client';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from 'recharts';

export default function TrendChart({ data }: { data: any[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
        <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d?.slice ? d.slice(5) : d} />
        <YAxis fontSize={11} />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="present" stroke="#22C55E" strokeWidth={2} name="Present" />
        <Line type="monotone" dataKey="late" stroke="#EAB308" strokeWidth={2} name="Late" />
        <Line type="monotone" dataKey="absent" stroke="#EF4444" strokeWidth={2} name="Absent" />
        <Line type="monotone" dataKey="rate" stroke="#2563EB" strokeWidth={2} name="Rate %" />
      </LineChart>
    </ResponsiveContainer>
  );
}

export { TrendChart };
