'use client';

import { MapPin, UserCheck, ShieldAlert } from 'lucide-react';

interface ActiveEmployeeLocation {
  id: string;
  name: string;
  department: string;
  lat: number;
  lng: number;
  status: 'present' | 'late';
  time: string;
}

const SAMPLE_LOCATIONS: ActiveEmployeeLocation[] = [
  { id: '1', name: 'John Doe', department: 'Engineering', lat: 28.6140, lng: 77.2092, status: 'present', time: '09:15 AM' },
  { id: '2', name: 'Priya Sharma', department: 'Product', lat: 28.6138, lng: 77.2089, status: 'present', time: '09:22 AM' },
  { id: '3', name: 'Amit Patel', department: 'Sales', lat: 28.6142, lng: 77.2095, status: 'late', time: '09:44 AM' },
];

export function LiveEmployeeMap({ locations = SAMPLE_LOCATIONS }: { locations?: ActiveEmployeeLocation[] }) {
  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-bold text-slate-900 text-sm">Live Geofence Telemetry</h3>
          <p className="text-xs text-slate-500">Real-time check-in coordinates at Main Office</p>
        </div>
        <span className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-200">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" /> Live Signal
        </span>
      </div>

      <div className="relative h-64 bg-slate-950 rounded-xl overflow-hidden p-4 flex flex-col justify-between border border-slate-800">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />
        
        {/* Perimeter indicator */}
        <div className="absolute inset-10 border-2 border-dashed border-blue-500/40 rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-blue-500 rounded-full shadow-[0_0_15px_#3b82f6]" />
        </div>

        <div className="relative z-10 flex justify-between items-start text-[11px] text-slate-400 font-mono">
          <span>Boundary: 100m</span>
          <span>Center: 28.6139, 77.2090</span>
        </div>

        {/* Live pins */}
        <div className="relative z-10 space-y-1.5 max-h-32 overflow-y-auto pr-1">
          {locations.map((loc) => (
            <div
              key={loc.id}
              className="flex items-center justify-between bg-slate-900/80 backdrop-blur-sm border border-slate-800 px-3 py-1.5 rounded-lg text-xs"
            >
              <div className="flex items-center gap-2">
                <MapPin className="h-3.5 w-3.5 text-emerald-400" />
                <span className="font-semibold text-slate-200">{loc.name}</span>
                <span className="text-[10px] text-slate-500">({loc.department})</span>
              </div>
              <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
                <span>{loc.time}</span>
                <span className={loc.status === 'late' ? 'text-amber-400 font-bold' : 'text-emerald-400'}>
                  {loc.status.toUpperCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
