'use client';

import { formatTime } from '@/lib/utils';
import { Download, Search, CheckCircle2, AlertCircle, Clock, XCircle } from 'lucide-react';
import { useState } from 'react';

export interface AttendanceRow {
  employeeId?: string;
  fullName: string;
  email: string;
  department: string;
  checkIn?: string | null;
  checkOut?: string | null;
  status: 'present' | 'late' | 'absent' | 'half-day' | 'leave';
  workHours?: number;
  checkInDistance?: number | null;
}

interface AttendanceTableProps {
  rows: AttendanceRow[];
  onExportCsv?: () => void;
}

export function AttendanceTable({ rows, onExportCsv }: AttendanceTableProps) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filtered = rows.filter((r) => {
    const matchesQuery =
      r.fullName.toLowerCase().includes(query.toLowerCase()) ||
      r.email.toLowerCase().includes(query.toLowerCase()) ||
      (r.employeeId && r.employeeId.toLowerCase().includes(query.toLowerCase())) ||
      r.department.toLowerCase().includes(query.toLowerCase());

    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'present':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="h-3 w-3" /> Present
          </span>
        );
      case 'late':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="h-3 w-3" /> Late
          </span>
        );
      case 'absent':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="h-3 w-3" /> Absent
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex flex-wrap gap-3 items-center justify-between">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-sm">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, ID or department..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-sm bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">All Statuses</option>
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>

        <button
          onClick={onExportCsv}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 transition-colors"
        >
          <Download className="h-4 w-4" />
          <span>Export CSV</span>
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50/75 text-xs uppercase tracking-wider text-slate-500 font-medium border-b border-slate-100">
            <tr>
              <th className="px-6 py-3.5">Employee</th>
              <th className="px-6 py-3.5">Department</th>
              <th className="px-6 py-3.5">Check In</th>
              <th className="px-6 py-3.5">Check Out</th>
              <th className="px-6 py-3.5">Work Hours</th>
              <th className="px-6 py-3.5">Geofence Distance</th>
              <th className="px-6 py-3.5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-normal text-slate-700">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-10 text-center text-slate-400">
                  No attendance records found matching filters.
                </td>
              </tr>
            ) : (
              filtered.map((row) => (
                <tr key={row.employeeId || row.email} className="hover:bg-slate-50/60 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-semibold text-slate-900">{row.fullName}</p>
                      <p className="text-xs text-slate-400">{row.employeeId || row.email}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-600">{row.department}</td>
                  <td className="px-6 py-4 font-mono text-xs">{formatTime(row.checkIn)}</td>
                  <td className="px-6 py-4 font-mono text-xs">{formatTime(row.checkOut)}</td>
                  <td className="px-6 py-4 font-medium">{row.workHours ? `${row.workHours}h` : '—'}</td>
                  <td className="px-6 py-4 text-xs text-slate-500">
                    {row.checkInDistance != null ? `${row.checkInDistance}m` : '—'}
                  </td>
                  <td className="px-6 py-4">{getStatusBadge(row.status)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
