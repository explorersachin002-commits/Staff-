'use client';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const COLORS = ['#2563EB', '#22C55E', '#EAB308', '#EF4444', '#8B5CF6', '#06B6D4'];

export default function DepartmentPie({ data }: { data: Record<string, any> }) {
  const chartData = Object.entries(data || {}).map(([name, v]: any) => ({
    name,
    value: (v?.present || 0) + (v?.late || 0),
  }));

  if (chartData.length === 0) {
    return <div className="text-sm text-slate-400 text-center py-16">No data for today.</div>;
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie data={chartData} dataKey="value" nameKey="name" outerRadius={90} label>
          {chartData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}

export { DepartmentPie };
