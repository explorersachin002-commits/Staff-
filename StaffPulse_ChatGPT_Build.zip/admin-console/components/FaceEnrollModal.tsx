'use client';

import { useState } from 'react';
import { Camera, Upload, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { api } from '@/lib/api';

interface FaceEnrollModalProps {
  employeeId: string;
  employeeName: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (faceId: string) => void;
}

export function FaceEnrollModal({ employeeId, employeeName, isOpen, onClose, onSuccess }: FaceEnrollModalProps) {
  const [base64, setBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setBase64(reader.result as string);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleEnroll = async () => {
    if (!base64) return;
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.post(`/employees/${employeeId}/enroll-face`, {
        selfieBase64: base64,
      });
      onSuccess(data.faceId);
      onClose();
    } catch (err: any) {
      setError(err?.response?.data?.error || err.message || 'Face enrollment failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl border border-slate-200">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-bold text-lg text-slate-900">Biometric Face Enrollment</h3>
            <p className="text-xs text-slate-500">Register AWS Rekognition vector for {employeeName}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 p-1">
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 flex flex-col items-center justify-center text-center mb-5 hover:border-blue-400 transition-colors">
          {base64 ? (
            <div className="space-y-3">
              <img src={base64} alt="Preview" className="h-36 w-36 object-cover rounded-full mx-auto border-4 border-blue-500/20 shadow-sm" />
              <p className="text-xs text-emerald-600 font-semibold flex items-center justify-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5" /> High Quality Portrait Selected
              </p>
            </div>
          ) : (
            <label className="cursor-pointer space-y-2">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-full mx-auto w-fit">
                <Camera className="h-6 w-6" />
              </div>
              <p className="text-sm font-semibold text-slate-700">Upload Enrollment Photo</p>
              <p className="text-xs text-slate-400">Frontal portrait, clear lighting, no accessories</p>
              <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
            </label>
          )}
        </div>

        <div className="flex justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!base64 || loading}
            onClick={handleEnroll}
            className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-sm transition-all disabled:opacity-50"
          >
            {loading ? 'Processing AWS Vector...' : 'Confirm Enrollment'}
          </button>
        </div>
      </div>
    </div>
  );
}
