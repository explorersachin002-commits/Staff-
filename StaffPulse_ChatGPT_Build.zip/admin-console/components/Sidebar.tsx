'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { api } from '@/lib/api';

const nav = [
  { href: '/dashboard', label: 'Dashboard', icon: '📊' },
  { href: '/attendance', label: 'Attendance', icon: '📋' },
  { href: '/employees', label: 'Employees', icon: '👥' },
  { href: '/geofences', label: 'Geofences', icon: '📍' },
  { href: '/live', label: 'Live Map', icon: '🗺️' },
  { href: '/audit', label: 'Audit Log', icon: '🔒' },
  { href: '/settings', label: 'Settings', icon: '⚙️' },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  const signOut = async () => {
    try {
      const refreshToken = localStorage.getItem('refreshToken');
      if (refreshToken) await api.post('/auth/logout', { refreshToken });
    } catch {}
    localStorage.clear();
    router.push('/login');
  };

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🕐</span>
          <div>
            <div className="font-bold">Attendance</div>
            <div className="text-xs text-slate-400">Admin Console</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {nav.map((item) => {
          const active = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href} href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${
                active ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button
          onClick={signOut}
          className="w-full text-left text-sm text-red-400 hover:bg-slate-800 px-3 py-2 rounded-lg"
        >
          ↩ Sign Out
        </button>
      </div>
    </aside>
  );
}

export { Sidebar };
