'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import KpiCard from '@/components/KpiCard';
import TrendChart from '@/components/TrendChart';
import DepartmentPie from '@/components/DepartmentPie';

export default function DashboardPage() {
  const [trends, setTrends] = useState<any[]>([]);
  const [dept, setDept] = useState<any>({});
  const [stats, setStats] = useState<any>({ totalEmployees: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/dashboard/trends?days=7')
      .then((r) => {
        setTrends(r.data.trends || []);
        setDept(r.data.departmentBreakdown || {});
        setStats({ totalEmployees: r.data.totalEmployees || 0 });
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-8 text-slate-500">Loading dashboard…</div>;

  const today = trends[trends.length - 1] || { present: 0, late: 0, absent: 0, rate: 0 };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500">Overview of today's attendance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <KpiCard label="Total Employees" value={stats.totalEmployees} icon="👥" />
        <KpiCard label="Present" value={today.present} icon="✅" color="text-green-600" />
        <KpiCard label="Late" value={today.late} icon="⏰" color="text-amber-600" />
        <KpiCard label="Absent" value={today.absent} icon="❌" color="text-red-600" />
        <KpiCard label="Attendance Rate" value={`${today.rate}%`} icon="📈" color="text-blue-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="font-semibold text-slate-900 mb-4">7-Day Attendance Trend</h2>
          <TrendChart data={trends} />
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="font-semibold text-slate-900 mb-4">By Department</h2>
          <DepartmentPie data={dept} />
        </div>
      </div>
    </div>
  );
}
