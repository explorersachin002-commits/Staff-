'use client';
import { useEffect, useState } from 'react';
import Map, { Marker, Popup, NavigationControl } from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function LiveMapPage() {
  const [points, setPoints] = useState<any[]>([]);
  const [popup, setPopup] = useState<any>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const load = async () => {
    try {
      const { data } = await api.get('/admin/live/locations');
      setPoints(data.points || []);
      setLastUpdate(new Date());
    } catch (err) {
      console.warn('Failed to load live locations', err);
    }
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 30000); // refresh every 30s
    return () => clearInterval(t);
  }, []);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Live Locations</h1>
          <p className="text-sm text-slate-500">
            {points.length} checked-in · updated {format(lastUpdate, 'HH:mm:ss')}
          </p>
        </div>
        <button onClick={load} className="bg-slate-200 hover:bg-slate-300 px-3 py-2 rounded-lg text-sm">
          🔄 Refresh
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden" style={{ height: 650 }}>
        <Map
          initialViewState={{ longitude: 77.2090, latitude: 28.6139, zoom: 11 }}
          mapStyle="mapbox://styles/mapbox/streets-v12"
          mapboxAccessToken={process.env.NEXT_PUBLIC_MAPBOX_TOKEN}
        >
          <NavigationControl position="top-right" />

          {points.map((p) => (
            <Marker
              key={p.userId}
              longitude={p.coordinates[0]}
              latitude={p.coordinates[1]}
              onClick={(e) => { e.originalEvent.stopPropagation(); setPopup(p); }}
            >
              <div className={`w-4 h-4 rounded-full border-2 border-white shadow ${
                p.status === 'late' ? 'bg-amber-500' : 'bg-green-500'
              }`} />
            </Marker>
          ))}

          {popup && (
            <Popup
              longitude={popup.coordinates[0]}
              latitude={popup.coordinates[1]}
              onClose={() => setPopup(null)}
              closeOnClick={false}
            >
              <div className="text-xs">
                <div className="font-semibold">{popup.fullName}</div>
                <div className="text-slate-500">{popup.department}</div>
                <div className="mt-1">
                  Checked in: {popup.checkInTime ? format(new Date(popup.checkInTime), 'HH:mm') : '—'}
                </div>
                <div>Status: {popup.status}</div>
              </div>
            </Popup>
          )}
        </Map>
      </div>
    </div>
  );
}
