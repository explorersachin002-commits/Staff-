'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function AttendancePage() {
  const today = new Date().toISOString().split('T')[0];
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];

  const [from, setFrom] = useState(weekAgo);
  const [to, setTo] = useState(today);
  const [status, setStatus] = useState('');
  const [department, setDepartment] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>({ page: 1, pages: 1 });
  const [loading, setLoading] = useState(true);

  const load = async (page = 1) => {
    setLoading(true);
    try {
      const params: any = { from, to, page, limit: 50 };
      if (status) params.status = status;
      if (department) params.department = department;
      const { data } = await api.get('/admin/attendance/report', { params });
      setRows(data.data || []);
      setPagination(data.pagination || { page: 1, pages: 1 });
    } catch (err) {
      console.warn('Failed to load attendance report', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(1); }, [from, to, status, department]);

  const exportCsv = async () => {
    const params = new URLSearchParams({ from, to, format: 'csv' });
    if (status) params.append('status', status);
    if (department) params.append('department', department);

    const token = localStorage.getItem('accessToken');
    const apiBase = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';
    const res = await fetch(
      `${apiBase}/admin/attendance/report?${params}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_${from}_to_${to}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Attendance Records</h1>
          <p className="text-sm text-slate-500">Filter, review, and export attendance data</p>
        </div>
        <button
          onClick={exportCsv}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
        >
          ⬇ Export CSV
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-4 mb-4 flex flex-wrap gap-3">
        <div>
          <label className="text-xs font-medium text-slate-600 block mb-1">From</label>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-600 block mb-1">To</label>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-600 block mb-1">Status</label>
          <select value={status} onChange={(e) => setStatus(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm">
            <option value="">All</option>
            <option value="present">Present</option>
            <option value="late">Late</option>
            <option value="absent">Absent</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-600 block mb-1">Department</label>
          <input placeholder="Any" value={department} onChange={(e) => setDepartment(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-sm" />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
            <tr>
              <th className="px-4 py-3 text-left">Date</th>
              <th className="px-4 py-3 text-left">Employee</th>
              <th className="px-4 py-3 text-left">Department</th>
              <th className="px-4 py-3 text-left">Check In</th>
              <th className="px-4 py-3 text-left">Check Out</th>
              <th className="px-4 py-3 text-left">Hours</th>
              <th className="px-4 py-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-500">Loading…</td></tr>
            ) : rows.length === 0 ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-500">No records.</td></tr>
            ) : rows.map((r, i) => (
              <tr key={i} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-3 text-slate-700">{r.date}</td>
                <td className="px-4 py-3">
                  <div className="font-medium text-slate-900">{r.fullName}</div>
                  <div className="text-xs text-slate-500">{r.employeeId}</div>
                </td>
                <td className="px-4 py-3 text-slate-600">{r.department}</td>
                <td className="px-4 py-3 text-slate-700">
                  {r.checkIn ? format(new Date(r.checkIn), 'HH:mm') : '—'}
                </td>
                <td className="px-4 py-3 text-slate-700">
                  {r.checkOut ? format(new Date(r.checkOut), 'HH:mm') : '—'}
                </td>
                <td className="px-4 py-3 text-slate-700">{r.workHours || 0}h</td>
                <td className="px-4 py-3">
                  <StatusChip status={r.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {pagination?.pages > 1 && (
          <div className="flex justify-between items-center px-4 py-3 border-t bg-slate-50 text-sm">
            <span className="text-slate-500">
              Page {pagination.page} of {pagination.pages}
            </span>
            <div className="space-x-2">
              <button
                disabled={pagination.page <= 1}
                onClick={() => load(pagination.page - 1)}
                className="px-3 py-1 border rounded disabled:opacity-40"
              >Prev</button>
              <button
                disabled={pagination.page >= pagination.pages}
                onClick={() => load(pagination.page + 1)}
                className="px-3 py-1 border rounded disabled:opacity-40"
              >Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusChip({ status }: { status: string }) {
  const colors: Record<string, string> = {
    present: 'bg-green-50 text-green-700',
    late: 'bg-amber-50 text-amber-700',
    absent: 'bg-red-50 text-red-700',
    leave: 'bg-purple-50 text-purple-700',
  };
  return (
    <span className={`px-2 py-1 rounded text-xs font-medium ${colors[status] || 'bg-slate-100 text-slate-600'}`}>
      {status ? status.toUpperCase() : 'UNKNOWN'}
    </span>
  );
}
