'use client';
import { useEffect, useState } from 'react';
import Map, { Marker, NavigationControl, Source, Layer } from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { api } from '@/lib/api';

function Circle({
  longitude,
  latitude,
  radius,
  fillColor = '#2563EB',
  fillOpacity = 0.15,
  strokeColor = '#2563EB',
  strokeWidth = 2,
}: {
  longitude: number;
  latitude: number;
  radius: number;
  fillColor?: string;
  fillOpacity?: number;
  strokeColor?: string;
  strokeWidth?: number;
}) {
  const points = 64;
  const km = radius / 1000;
  const coords: [number, number][] = [];
  const distanceX = km / (111.32 * Math.cos((latitude * Math.PI) / 180));
  const distanceY = km / 110.574;

  for (let i = 0; i < points; i++) {
    const theta = (i / points) * (2 * Math.PI);
    const x = distanceX * Math.cos(theta);
    const y = distanceY * Math.sin(theta);
    coords.push([longitude + x, latitude + y]);
  }
  coords.push(coords[0]);

  const geojson: any = {
    type: 'Feature',
    geometry: {
      type: 'Polygon',
      coordinates: [coords],
    },
  };

  const id = `circle-${longitude.toFixed(5)}-${latitude.toFixed(5)}-${radius}-${Math.random().toString(36).substring(2, 7)}`;

  return (
    <Source id={id} type="geojson" data={geojson}>
      <Layer
        id={`${id}-fill`}
        type="fill"
        paint={{
          'fill-color': fillColor,
          'fill-opacity': fillOpacity,
        }}
      />
      <Layer
        id={`${id}-line`}
        type="line"
        paint={{
          'line-color': strokeColor,
          'line-width': strokeWidth,
        }}
      />
    </Source>
  );
}

export default function GeofencesPage() {
  const [geofences, setGeofences] = useState<any[]>([]);
  const [draft, setDraft] = useState<any>({
    name: '', latitude: 28.6139, longitude: 77.2090, radiusMeters: 100,
  });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const { data } = await api.get('/geofences');
      setGeofences(data.geofences || []);
    } catch (err) {
      console.warn('Failed to load geofences', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!draft.name) return alert('Name required');
    setSaving(true);
    try {
      await api.post('/geofences', draft);
      setDraft({ name: '', latitude: draft.latitude, longitude: draft.longitude, radiusMeters: draft.radiusMeters });
      load();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Deactivate this geofence?')) return;
    try {
      await api.delete(`/geofences/${id}`);
      load();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to remove');
    }
  };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Geofences</h1>
        <p className="text-sm text-slate-500">Click on the map to place a new location, then save</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm overflow-hidden" style={{ height: 600 }}>
          <Map
            initialViewState={{
              longitude: draft.longitude,
              latitude: draft.latitude,
              zoom: 12,
            }}
            mapStyle="mapbox://styles/mapbox/streets-v12"
            mapboxAccessToken={process.env.NEXT_PUBLIC_MAPBOX_TOKEN}
            onClick={(e) => setDraft({
              ...draft,
              latitude: e.lngLat.lat,
              longitude: e.lngLat.lng,
            })}
          >
            <NavigationControl position="top-right" />

            {/* Existing geofences */}
            {geofences.map((gf) => {
              const [lng, lat] = gf.location.coordinates;
              return (
                <div key={gf._id}>
                  <Marker longitude={lng} latitude={lat}>
                    <div className="text-2xl">📍</div>
                  </Marker>
                  <Circle
                    longitude={lng} latitude={lat}
                    radius={gf.radiusMeters}
                    fillColor="#2563EB" fillOpacity={0.15}
                    strokeColor="#2563EB" strokeWidth={2}
                  />
                </div>
              );
            })}

            {/* Draft */}
            <Marker longitude={draft.longitude} latitude={draft.latitude}>
              <div className="text-2xl animate-pulse">🆕</div>
            </Marker>
            <Circle
              longitude={draft.longitude} latitude={draft.latitude}
              radius={draft.radiusMeters}
              fillColor="#F59E0B" fillOpacity={0.2}
              strokeColor="#F59E0B" strokeWidth={2}
            />
          </Map>
        </div>

        <div className="space-y-4">
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h2 className="font-semibold mb-3">New Geofence</h2>
            <div className="space-y-3 text-sm">
              <div>
                <label className="text-xs font-medium text-slate-600 block mb-1">Name</label>
                <input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  placeholder="e.g. HQ Main Office"
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-medium text-slate-600 block mb-1">Lat</label>
                  <input
                    type="number" step="0.000001"
                    value={draft.latitude}
                    onChange={(e) => setDraft({ ...draft, latitude: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600 block mb-1">Lng</label>
                  <input
                    type="number" step="0.000001"
                    value={draft.longitude}
                    onChange={(e) => setDraft({ ...draft, longitude: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border rounded-lg text-xs"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 block mb-1">
                  Radius: {draft.radiusMeters}m
                </label>
                <input
                  type="range" min="20" max="500" step="10"
                  value={draft.radiusMeters}
                  onChange={(e) => setDraft({ ...draft, radiusMeters: parseInt(e.target.value) || 100 })}
                  className="w-full"
                />
              </div>
              <button
                onClick={save} disabled={saving}
                className="w-full py-2 bg-blue-600 text-white rounded-lg text-sm font-medium disabled:opacity-50"
              >
                {saving ? 'Saving…' : 'Save Geofence'}
              </button>
              <p className="text-xs text-slate-400">
                Tip: click anywhere on the map to move the marker
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h2 className="font-semibold mb-3">Active ({geofences.length})</h2>
            <div className="space-y-2">
              {geofences.filter((g) => g.isActive).map((gf) => (
                <div key={gf._id} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50">
                  <div>
                    <div className="text-sm font-medium">{gf.name}</div>
                    <div className="text-xs text-slate-500">{gf.radiusMeters}m radius</div>
                  </div>
                  <button
                    onClick={() => remove(gf._id)}
                    className="text-xs text-red-600 hover:underline"
                  >
                    Remove
                  </button>
                </div>
              ))}
              {geofences.length === 0 && (
                <div className="text-xs text-slate-400 text-center py-4">No geofences yet</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
