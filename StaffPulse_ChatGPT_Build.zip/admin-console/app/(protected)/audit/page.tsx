'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function AuditPage() {
  const [logs, setLogs] = useState<any[]>([]);
  const [filter, setFilter] = useState({ action: '', page: 1 });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const params: any = { page: filter.page, limit: 50 };
      if (filter.action) params.action = filter.action;
      const { data } = await api.get('/employees/audit/logs', { params });
      setLogs(data.data || []);
    } catch (err) {
      console.warn('Failed to load audit logs', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [filter]);

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">Audit Log</h1>

      <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
        <input
          placeholder="Filter by action (e.g. FACE_ENROLLED)"
          value={filter.action}
          onChange={(e) => setFilter({ ...filter, action: e.target.value, page: 1 })}
          className="w-full px-3 py-2 border rounded-lg text-sm"
        />
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 text-left">Time</th>
              <th className="px-4 py-3 text-left">Actor</th>
              <th className="px-4 py-3 text-left">Action</th>
              <th className="px-4 py-3 text-left">Target</th>
              <th className="px-4 py-3 text-left">IP</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} className="p-8 text-center text-slate-500">Loading…</td></tr>
            ) : logs.length === 0 ? (
              <tr><td colSpan={5} className="p-8 text-center text-slate-500">No audit logs found.</td></tr>
            ) : logs.map((l) => (
              <tr key={l._id} className="border-t border-slate-100">
                <td className="px-4 py-3 text-slate-600 text-xs">
                  {format(new Date(l.timestamp), 'MMM d, HH:mm:ss')}
                </td>
                <td className="px-4 py-3">{l.actorId?.fullName || 'System'}</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-slate-100 rounded text-xs font-mono">
                    {l.action}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-500 text-xs">{l.targetType || '—'}</td>
                <td className="px-4 py-3 text-slate-500 text-xs">{l.ipAddress || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
