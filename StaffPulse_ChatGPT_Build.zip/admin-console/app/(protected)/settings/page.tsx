'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';

export default function SettingsPage() {
  const [settings, setSettings] = useState<any>(null);

  useEffect(() => {
    api.get('/admin/settings')
      .then((r) => setSettings(r.data))
      .catch((err) => console.warn('Failed to load settings', err));
  }, []);

  if (!settings) return <div className="p-8 text-slate-500">Loading…</div>;

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">Settings</h1>
      <div className="bg-white rounded-2xl shadow-sm p-6 max-w-xl">
        <div className="space-y-4">
          {[
            ['Workday Start', settings.workdayStart],
            ['Workday End', settings.workdayEnd],
            ['Late Threshold', settings.lateThreshold],
            ['Face Match Threshold', `${settings.faceMatchThreshold}%`],
            ['GPS Accuracy Limit', `${settings.gpsAccuracyLimit}m`],
            ['Timezone', settings.timezone],
          ].map(([k, v]) => (
            <div key={k as string} className="flex items-center justify-between py-2 border-b border-slate-100">
              <span className="text-sm text-slate-600">{k}</span>
              <span className="text-sm font-medium text-slate-900">{v}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-4">
          Note: Settings are read-only in Phase 4. Editable config arrives in Phase 5.
        </p>
      </div>
    </div>
  );
}
