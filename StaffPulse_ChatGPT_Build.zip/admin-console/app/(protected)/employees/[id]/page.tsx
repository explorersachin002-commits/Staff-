'use client';
import { useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function EmployeeDetailPage() {
  const { id } = useParams() as { id: string };
  const router = useRouter();
  const [emp, setEmp] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [enrollOpen, setEnrollOpen] = useState(false);

  useEffect(() => {
    api.get(`/admin/employees/${id}`).then((r) => {
      setEmp(r.data);
      // Fetch employee's recent attendance
      api.get(`/admin/attendance/report?limit=20`).then((res) => {
        const matching = (res.data?.data || []).filter(
          (x: any) => x.employeeId === r.data.employeeId || x.fullName === r.data.fullName
        );
        setHistory(matching);
      });
    });
  }, [id]);

  if (!emp) return <div className="p-8 text-slate-500">Loading…</div>;

  return (
    <div className="p-8">
      <button onClick={() => router.back()} className="text-sm text-blue-600 mb-4">← Back</button>

      <div className="bg-white rounded-2xl shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{emp.fullName}</h1>
            <p className="text-sm text-slate-500">{emp.email} · {emp.employeeId || '—'}</p>
          </div>
          <button
            onClick={() => setEnrollOpen(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm"
          >
            📸 {emp.hasFaceEnrolled ? 'Re-enroll Face' : 'Enroll Face'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6 text-sm">
          <Info label="Department" value={emp.department || '—'} />
          <Info label="Role" value={emp.role || 'employee'} />
          <Info label="Status" value={emp.isActive !== false ? 'Active' : 'Inactive'} />
          <Info label="Face Enrolled" value={emp.hasFaceEnrolled ? '✓ Yes' : 'No'} />
          <Info label="Device Bound" value={emp.hasDeviceBound ? '✓ Yes' : 'No'} />
          <Info label="Created" value={emp.createdAt ? format(new Date(emp.createdAt), 'PP') : '—'} />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-6">
        <h2 className="font-semibold mb-4">Recent Attendance</h2>
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 border-b">
            <tr>
              <th className="py-2 text-left">Date</th>
              <th className="py-2 text-left">In</th>
              <th className="py-2 text-left">Out</th>
              <th className="py-2 text-left">Hours</th>
              <th className="py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {history.length === 0 ? (
              <tr><td colSpan={5} className="py-4 text-center text-slate-400">No attendance history found.</td></tr>
            ) : history.map((r, i) => (
              <tr key={i} className="border-b border-slate-50">
                <td className="py-2">{r.date}</td>
                <td className="py-2">{r.checkIn ? format(new Date(r.checkIn), 'HH:mm') : '—'}</td>
                <td className="py-2">{r.checkOut ? format(new Date(r.checkOut), 'HH:mm') : '—'}</td>
                <td className="py-2">{r.workHours || 0}h</td>
                <td className="py-2">{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {enrollOpen && (
        <EnrollModal
          employeeId={id}
          onClose={() => {
            setEnrollOpen(false);
            api.get(`/admin/employees/${id}`).then((r) => setEmp(r.data));
          }}
        />
      )}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-slate-900 font-medium">{value}</div>
    </div>
  );
}

function EnrollModal({ employeeId, onClose }: { employeeId: string; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [streaming, setStreaming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const handleClose = () => {
    stopStream();
    onClose();
  };

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setStreaming(true);
      }
    } catch (e: any) {
      setError('Camera access denied: ' + e.message);
    }
  };

  const capture = async () => {
    if (!videoRef.current) return;
    setBusy(true);
    setError('');
    try {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      canvas.getContext('2d')!.drawImage(videoRef.current, 0, 0);
      const base64 = canvas.toDataURL('image/jpeg', 0.85);

      await api.post(`/employees/${employeeId}/enroll-face`, { selfieBase64: base64 });
      handleClose();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Enrollment failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-lg">
        <h2 className="text-lg font-bold mb-4">Enroll Face</h2>

        <div className="rounded-xl overflow-hidden bg-slate-900 aspect-video mb-4 flex items-center justify-center">
          <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
        </div>

        {error && <div className="bg-red-50 text-red-700 text-xs p-2 rounded mb-3">{error}</div>}

        <div className="flex gap-2">
          {!streaming ? (
            <button onClick={start} className="flex-1 py-2 bg-slate-200 rounded-lg text-sm">
              Start Camera
            </button>
          ) : (
            <button
              onClick={capture}
              disabled={busy}
              className="flex-1 py-2 bg-blue-600 text-white rounded-lg text-sm disabled:opacity-50"
            >
              {busy ? 'Enrolling…' : '📸 Capture & Enroll'}
            </button>
          )}
          <button onClick={handleClose} className="px-4 py-2 border rounded-lg text-sm">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
