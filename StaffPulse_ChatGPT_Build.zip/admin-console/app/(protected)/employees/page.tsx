'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';

export default function EmployeesPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/admin/employees', { params: { search, limit: 100 } });
      setRows(data.data || []);
    } catch (err) {
      console.warn('Failed to load employees', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [search]);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Employees</h1>
          <p className="text-sm text-slate-500">Manage employee accounts and enrollment</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
        >
          + Add Employee
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
        <input
          placeholder="Search by name, email, or ID…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full px-4 py-2 border border-slate-200 rounded-lg text-sm"
        />
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
            <tr>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Email</th>
              <th className="px-4 py-3 text-left">Department</th>
              <th className="px-4 py-3 text-left">Face</th>
              <th className="px-4 py-3 text-left">Device</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-500">Loading…</td></tr>
            ) : rows.length === 0 ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-500">No employees found.</td></tr>
            ) : rows.map((r) => (
              <tr key={r._id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-4 py-3">
                  <div className="font-medium text-slate-900">{r.fullName}</div>
                  <div className="text-xs text-slate-500">{r.employeeId}</div>
                </td>
                <td className="px-4 py-3 text-slate-600">{r.email}</td>
                <td className="px-4 py-3 text-slate-600">{r.department}</td>
                <td className="px-4 py-3">
                  {r.hasFaceEnrolled
                    ? <span className="text-green-600 text-xs font-medium">✓ Enrolled</span>
                    : <span className="text-slate-400 text-xs">Not enrolled</span>}
                </td>
                <td className="px-4 py-3">
                  {r.hasDeviceBound
                    ? <span className="text-green-600 text-xs font-medium">✓ Bound</span>
                    : <span className="text-slate-400 text-xs">—</span>}
                </td>
                <td className="px-4 py-3">
                  {r.isActive
                    ? <span className="text-xs text-green-600 font-medium">Active</span>
                    : <span className="text-xs text-red-600 font-medium">Inactive</span>}
                </td>
                <td className="px-4 py-3">
                  <Link href={`/employees/${r._id}`} className="text-blue-600 text-xs font-medium hover:underline">
                    Manage →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showCreate && <CreateModal onClose={() => { setShowCreate(false); load(); }} />}
    </div>
  );
}

function CreateModal({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({
    email: '', password: '', fullName: '', department: 'Engineering', employeeId: '', role: 'employee',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/admin/employees', form);
      onClose();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md">
        <h2 className="text-lg font-bold mb-4">Add Employee</h2>
        <form onSubmit={submit} className="space-y-3">
          {[
            ['fullName', 'Full Name', 'text'],
            ['email', 'Email', 'email'],
            ['password', 'Password', 'password'],
            ['employeeId', 'Employee ID', 'text'],
            ['department', 'Department', 'text'],
          ].map(([key, label, type]) => (
            <div key={key}>
              <label className="text-xs font-medium text-slate-600 block mb-1">{label}</label>
              <input
                type={type as string}
                value={(form as any)[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                required={key !== 'employeeId'}
              />
            </div>
          ))}
          {error && <div className="text-red-600 text-xs">{error}</div>}
          <div className="flex gap-2 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2 border rounded-lg text-sm">
              Cancel
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2 bg-blue-600 text-white rounded-lg text-sm disabled:opacity-50">
              {loading ? 'Creating…' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
