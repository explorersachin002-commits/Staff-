package com.example.backend.utils

import com.example.model.AuthTokens
import java.util.UUID

object TokenUtils {
    fun generateTokens(userId: String, role: String): AuthTokens {
        val uniqueAccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9." +
                "eyJzdWIiOiIkuserIdIiwicm9sZSI6IiRyb2xlIiwiaWF0IjoxNzA5MDAwMDAwLCJleHAiOjE3MDkwMDM2MDB9." +
                UUID.randomUUID().toString().replace("-", "").take(24)

        val uniqueRefreshToken = "rt_" + UUID.randomUUID().toString().replace("-", "")

        return AuthTokens(
            accessToken = uniqueAccessToken,
            refreshToken = uniqueRefreshToken,
            tokenType = "Bearer",
            expiresInSeconds = 3600L,
            issuedAt = System.currentTimeMillis()
        )
    }

    fun isTokenValid(token: String): Boolean {
        return token.startsWith("eyJ") && token.length > 30
    }
}
