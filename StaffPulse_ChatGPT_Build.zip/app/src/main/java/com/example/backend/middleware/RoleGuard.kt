package com.example.backend.middleware

import com.example.model.User
import com.example.model.UserRole

/**
 * Simulates role-based authorization guard checking permissions before privileged actions.
 */
object RoleGuard {
    fun requireAdmin(user: User?): Result<Unit> {
        if (user == null) {
            return Result.failure(IllegalStateException("Unauthorized: No active user session."))
        }
        if (user.role != UserRole.ADMIN) {
            return Result.failure(SecurityException("Forbidden: Administrator privileges required."))
        }
        return Result.success(Unit)
    }

    fun requireEmployee(user: User?): Result<Unit> {
        if (user == null) {
            return Result.failure(IllegalStateException("Unauthorized: No active user session."))
        }
        return Result.success(Unit)
    }
}
