package com.example.backend.middleware

import java.util.concurrent.ConcurrentHashMap

/**
 * Simulates API rate limiting middleware to prevent brute force and replay abuse.
 */
object RateLimiter {
    private val attemptsMap = ConcurrentHashMap<String, MutableList<Long>>()
    private const val MAX_ATTEMPTS = 5
    private const val WINDOW_MILLIS = 60_000L // 1 minute window

    @Synchronized
    fun isAllowed(key: String): Boolean {
        val now = System.currentTimeMillis()
        val list = attemptsMap.getOrPut(key) { mutableListOf() }
        
        // Remove timestamps older than window
        list.removeAll { now - it > WINDOW_MILLIS }
        
        if (list.size >= MAX_ATTEMPTS) {
            return false
        }
        
        list.add(now)
        return true
    }

    @Synchronized
    fun reset(key: String) {
        attemptsMap.remove(key)
    }
}
