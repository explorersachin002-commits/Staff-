package com.example.backend.data

import com.example.backend.middleware.RateLimiter
import com.example.backend.middleware.RoleGuard
import com.example.backend.utils.TokenUtils
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object AttendanceRepository {
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val dayFormat = SimpleDateFormat("EEEE", Locale.US)

    // Pre-seeded users
    private val adminUser = User(
        id = "usr_admin_01",
        name = "Sarah Jenkins",
        email = "admin@company.com",
        role = UserRole.ADMIN,
        department = "People & Operations",
        employeeCode = "ADM-1001",
        designation = "VP of People Operations",
        avatarInitials = "SJ",
        joinDate = "2021-03-15",
        phone = "+1 (555) 234-5678"
    )

    private val employeeAlex = User(
        id = "usr_emp_01",
        name = "Alex Morgan",
        email = "alex@company.com",
        role = UserRole.EMPLOYEE,
        department = "Engineering",
        employeeCode = "EMP-2045",
        designation = "Senior Software Engineer",
        avatarInitials = "AM",
        joinDate = "2023-06-01",
        phone = "+1 (555) 876-5432",
        leaveBalanceCasual = 10,
        leaveBalanceSick = 6,
        leaveBalanceAnnual = 15
    )

    private val userDatabase = mutableListOf(
        adminUser,
        employeeAlex,
        User(
            id = "usr_emp_john",
            name = "John Doe",
            email = "john@company.com",
            role = UserRole.EMPLOYEE,
            department = "Engineering",
            employeeCode = "EMP001",
            designation = "Staff Software Engineer",
            avatarInitials = "JD",
            joinDate = "2023-01-15",
            phone = "+1 (555) 345-6789"
        ),
        User(
            id = "usr_emp_02",
            name = "David Chen",
            email = "david@company.com",
            role = UserRole.EMPLOYEE,
            department = "Product Design",
            employeeCode = "EMP-2046",
            designation = "Lead UX Designer",
            avatarInitials = "DC",
            joinDate = "2023-08-15",
            leaveBalanceCasual = 8,
            leaveBalanceSick = 7,
            leaveBalanceAnnual = 14
        ),
        User(
            id = "usr_emp_03",
            name = "Elena Rostova",
            email = "elena@company.com",
            role = UserRole.EMPLOYEE,
            department = "Product",
            employeeCode = "EMP-2047",
            designation = "Senior Product Manager",
            avatarInitials = "ER",
            joinDate = "2022-11-10",
            leaveBalanceCasual = 11,
            leaveBalanceSick = 8,
            leaveBalanceAnnual = 12
        ),
        User(
            id = "usr_emp_04",
            name = "Marcus Vance",
            email = "marcus@company.com",
            role = UserRole.EMPLOYEE,
            department = "Engineering",
            employeeCode = "EMP-2048",
            designation = "QA Automation Lead",
            avatarInitials = "MV",
            joinDate = "2024-01-20"
        ),
        User(
            id = "usr_emp_05",
            name = "Priya Sharma",
            email = "priya@company.com",
            role = UserRole.EMPLOYEE,
            department = "Cloud Infrastructure",
            employeeCode = "EMP-2049",
            designation = "Staff DevOps Engineer",
            avatarInitials = "PS",
            joinDate = "2022-04-12"
        ),
        User(
            id = "usr_emp_06",
            name = "Liam O'Connor",
            email = "liam@company.com",
            role = UserRole.EMPLOYEE,
            department = "Marketing",
            employeeCode = "EMP-2050",
            designation = "Growth Marketing Manager",
            avatarInitials = "LO",
            joinDate = "2024-03-01"
        )
    )

    // Current Session State
    private val _currentUser = MutableStateFlow<User?>(employeeAlex)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _authTokens = MutableStateFlow<AuthTokens?>(
        TokenUtils.generateTokens(employeeAlex.id, employeeAlex.role.name)
    )
    val authTokens: StateFlow<AuthTokens?> = _authTokens.asStateFlow()

    // Shift Settings
    private val _shiftSchedule = MutableStateFlow(ShiftSchedule())
    val shiftSchedule: StateFlow<ShiftSchedule> = _shiftSchedule.asStateFlow()

    // Today's attendance list
    private val _attendanceRecords = MutableStateFlow<List<AttendanceRecord>>(emptyList())
    val attendanceRecords: StateFlow<List<AttendanceRecord>> = _attendanceRecords.asStateFlow()

    // Leave Requests
    private val _leaveRequests = MutableStateFlow<List<LeaveRequest>>(emptyList())
    val leaveRequests: StateFlow<List<LeaveRequest>> = _leaveRequests.asStateFlow()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val todayStr = dateFormat.format(Date())
        val todayDay = dayFormat.format(Date())

        val initialAttendance = mutableListOf(
            AttendanceRecord(
                id = "att_today_01",
                userId = "usr_emp_01", // Alex Morgan
                employeeName = "Alex Morgan",
                employeeCode = "EMP-2045",
                department = "Engineering",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = "09:02 AM",
                checkOutTime = null,
                status = AttendanceStatus.PRESENT,
                location = "HQ Main Campus (Floor 4)",
                workHours = 4.5,
                notes = "On-site sprint review"
            ),
            AttendanceRecord(
                id = "att_today_02",
                userId = "usr_emp_02", // David Chen
                employeeName = "David Chen",
                employeeCode = "EMP-2046",
                department = "Product Design",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = "09:32 AM",
                checkOutTime = null,
                status = AttendanceStatus.LATE,
                location = "HQ Main Campus (Design Studio)",
                workHours = 4.0,
                notes = "Traffic delay on subway line 2"
            ),
            AttendanceRecord(
                id = "att_today_03",
                userId = "usr_emp_03", // Elena Rostova
                employeeName = "Elena Rostova",
                employeeCode = "EMP-2047",
                department = "Product",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = null,
                checkOutTime = null,
                status = AttendanceStatus.ON_LEAVE,
                location = "Remote",
                workHours = 0.0,
                notes = "Approved annual vacation"
            ),
            AttendanceRecord(
                id = "att_today_04",
                userId = "usr_emp_04", // Marcus Vance
                employeeName = "Marcus Vance",
                employeeCode = "EMP-2048",
                department = "Engineering",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = "08:52 AM",
                checkOutTime = null,
                status = AttendanceStatus.PRESENT,
                location = "HQ Main Campus (Floor 3)",
                workHours = 4.7,
                notes = "Early testing prep"
            ),
            AttendanceRecord(
                id = "att_today_05",
                userId = "usr_emp_05", // Priya Sharma
                employeeName = "Priya Sharma",
                employeeCode = "EMP-2049",
                department = "Cloud Infrastructure",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = "09:08 AM",
                checkOutTime = null,
                status = AttendanceStatus.PRESENT,
                location = "Remote / VPN Cluster",
                workHours = 4.4,
                notes = "Cloud migration monitoring"
            ),
            AttendanceRecord(
                id = "att_today_06",
                userId = "usr_emp_06", // Liam O'Connor
                employeeName = "Liam O'Connor",
                employeeCode = "EMP-2050",
                department = "Marketing",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = null,
                checkOutTime = null,
                status = AttendanceStatus.ABSENT,
                location = "Unreported",
                workHours = 0.0,
                notes = "No punch recorded yet"
            ),
            AttendanceRecord(
                id = "att_today_07",
                userId = "usr_admin_01", // Sarah Jenkins
                employeeName = "Sarah Jenkins",
                employeeCode = "ADM-1001",
                department = "People & Operations",
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = "08:45 AM",
                checkOutTime = null,
                status = AttendanceStatus.PRESENT,
                location = "Executive Suite (Floor 5)",
                workHours = 4.8,
                notes = "Executive operations"
            )
        )

        // Add 10 days of historical records for Alex Morgan to give full timesheet history
        val cal = Calendar.getInstance()
        val pastDaysData = listOf(
            Triple("Friday", "09:00 AM", "05:15 PM") to (AttendanceStatus.PRESENT to 8.25),
            Triple("Thursday", "08:55 AM", "05:30 PM") to (AttendanceStatus.PRESENT to 8.5),
            Triple("Wednesday", "09:22 AM", "05:40 PM") to (AttendanceStatus.LATE to 8.1),
            Triple("Tuesday", "09:01 AM", "05:00 PM") to (AttendanceStatus.PRESENT to 8.0),
            Triple("Monday", "08:58 AM", "05:10 PM") to (AttendanceStatus.PRESENT to 8.2),
            Triple("Friday", "09:05 AM", "01:30 PM") to (AttendanceStatus.HALF_DAY to 4.5),
            Triple("Thursday", "09:00 AM", "05:00 PM") to (AttendanceStatus.PRESENT to 8.0),
            Triple("Wednesday", "08:48 AM", "05:25 PM") to (AttendanceStatus.PRESENT to 8.4),
            Triple("Tuesday", "09:18 AM", "05:15 PM") to (AttendanceStatus.LATE to 7.9),
            Triple("Monday", "09:02 AM", "05:05 PM") to (AttendanceStatus.PRESENT to 8.1)
        )

        pastDaysData.forEachIndexed { index, pair ->
            cal.add(Calendar.DAY_OF_YEAR, -1)
            // Skip weekends
            while (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                cal.add(Calendar.DAY_OF_YEAR, -1)
            }
            val recordDate = dateFormat.format(cal.time)
            val dayName = dayFormat.format(cal.time)

            initialAttendance.add(
                AttendanceRecord(
                    id = "att_hist_$index",
                    userId = "usr_emp_01",
                    employeeName = "Alex Morgan",
                    employeeCode = "EMP-2045",
                    department = "Engineering",
                    date = recordDate,
                    dayOfWeek = dayName,
                    checkInTime = pair.first.second,
                    checkOutTime = pair.first.third,
                    status = pair.second.first,
                    location = "HQ Main Campus (Floor 4)",
                    workHours = pair.second.second,
                    overtimeMinutes = if (pair.second.second > 8.0) ((pair.second.second - 8.0) * 60).toInt() else 0,
                    notes = if (pair.second.first == AttendanceStatus.LATE) "Transit delay" else "Completed shift"
                )
            )
        }

        _attendanceRecords.value = initialAttendance

        // Seed Leaves
        _leaveRequests.value = listOf(
            LeaveRequest(
                id = "lev_01",
                userId = "usr_emp_02",
                employeeName = "David Chen",
                employeeCode = "EMP-2046",
                department = "Product Design",
                leaveType = LeaveType.SICK,
                startDate = "2026-10-15",
                endDate = "2026-10-16",
                daysCount = 2,
                reason = "Doctor appointment for chronic back treatment and physical therapy.",
                status = LeaveStatus.PENDING,
                appliedAt = "2026-10-11 02:40 PM"
            ),
            LeaveRequest(
                id = "lev_02",
                userId = "usr_emp_01",
                employeeName = "Alex Morgan",
                employeeCode = "EMP-2045",
                department = "Engineering",
                leaveType = LeaveType.CASUAL,
                startDate = "2026-10-19",
                endDate = "2026-10-19",
                daysCount = 1,
                reason = "Attending apartment lease renewal and DMV vehicle inspection.",
                status = LeaveStatus.PENDING,
                appliedAt = "2026-10-12 09:15 AM"
            ),
            LeaveRequest(
                id = "lev_03",
                userId = "usr_emp_04",
                employeeName = "Marcus Vance",
                employeeCode = "EMP-2048",
                department = "Engineering",
                leaveType = LeaveType.COMPENSATORY,
                startDate = "2026-10-23",
                endDate = "2026-10-23",
                daysCount = 1,
                reason = "Compensatory off for overnight release support on Sunday.",
                status = LeaveStatus.PENDING,
                appliedAt = "2026-10-10 11:20 AM"
            ),
            LeaveRequest(
                id = "lev_04",
                userId = "usr_emp_03",
                employeeName = "Elena Rostova",
                employeeCode = "EMP-2047",
                department = "Product",
                leaveType = LeaveType.ANNUAL,
                startDate = "2026-10-12",
                endDate = "2026-10-14",
                daysCount = 3,
                reason = "Annual family vacation trip.",
                status = LeaveStatus.APPROVED,
                appliedAt = "2026-10-05 10:00 AM",
                reviewedBy = "Sarah Jenkins (HR)",
                reviewNote = "Approved. Have a great vacation!"
            )
        )
    }

    // AUTH FUNCTIONS
    fun login(email: String, password: String): Result<Pair<User, AuthTokens>> {
        val cleanEmail = email.trim().lowercase()
        if (!RateLimiter.isAllowed(cleanEmail)) {
            return Result.failure(IllegalStateException("Too many attempts. Rate limit exceeded. Please wait a minute."))
        }

        // Demo login matching
        val user = userDatabase.find { it.email.lowercase() == cleanEmail }
            ?: return Result.failure(IllegalArgumentException("Invalid email address. User not found."))

        // In demo, password check
        if (password.length < 4) {
            return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        }

        val tokens = TokenUtils.generateTokens(user.id, user.role.name)
        _currentUser.value = user
        _authTokens.value = tokens
        RateLimiter.reset(cleanEmail)
        return Result.success(Pair(user, tokens))
    }

    fun switchActiveDemoUser(role: UserRole) {
        val target = if (role == UserRole.ADMIN) adminUser else employeeAlex
        _currentUser.value = target
        _authTokens.value = TokenUtils.generateTokens(target.id, target.role.name)
    }

    fun refreshAuthToken(): Result<AuthTokens> {
        val user = _currentUser.value ?: return Result.failure(IllegalStateException("No session active"))
        val newTokens = TokenUtils.generateTokens(user.id, user.role.name)
        _authTokens.value = newTokens
        return Result.success(newTokens)
    }

    fun logout() {
        _currentUser.value = null
        _authTokens.value = null
    }

    // CLOCK IN / OUT
    fun clockIn(userId: String, location: String = "HQ Main Campus (Building A)"): Result<AttendanceRecord> {
        val user = userDatabase.find { it.id == userId }
            ?: return Result.failure(IllegalArgumentException("Employee record not found"))

        val todayStr = dateFormat.format(Date())
        val todayDay = dayFormat.format(Date())
        val currentTime = timeFormat.format(Date())

        // Check if already clocked in today
        val currentList = _attendanceRecords.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.userId == userId && it.date == todayStr }

        // Determine if Late based on current hour/minute
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val isLate = (hour > 9) || (hour == 9 && minute > _shiftSchedule.value.gracePeriodMinutes)
        val status = if (isLate) AttendanceStatus.LATE else AttendanceStatus.PRESENT

        val updatedRecord: AttendanceRecord
        if (existingIndex >= 0) {
            val old = currentList[existingIndex]
            if (old.checkInTime != null && old.checkOutTime == null) {
                return Result.failure(IllegalStateException("Already clocked in at ${old.checkInTime}"))
            }
            updatedRecord = old.copy(
                checkInTime = currentTime,
                checkOutTime = null,
                status = status,
                location = location,
                notes = if (isLate) "Clocked in after grace period" else "On-time arrival"
            )
            currentList[existingIndex] = updatedRecord
        } else {
            updatedRecord = AttendanceRecord(
                id = "att_" + UUID.randomUUID().toString().take(8),
                userId = user.id,
                employeeName = user.name,
                employeeCode = user.employeeCode,
                department = user.department,
                date = todayStr,
                dayOfWeek = todayDay,
                checkInTime = currentTime,
                checkOutTime = null,
                status = status,
                location = location,
                workHours = 0.1,
                notes = if (isLate) "Clocked in after grace period" else "On-time arrival"
            )
            currentList.add(0, updatedRecord)
        }

        _attendanceRecords.value = currentList
        return Result.success(updatedRecord)
    }

    fun clockOut(userId: String, notes: String = "Regular day wrap-up"): Result<AttendanceRecord> {
        val todayStr = dateFormat.format(Date())
        val currentTime = timeFormat.format(Date())

        val currentList = _attendanceRecords.value.toMutableList()
        val index = currentList.indexOfFirst { it.userId == userId && it.date == todayStr }
        if (index < 0 || currentList[index].checkInTime == null) {
            return Result.failure(IllegalStateException("No active clock-in found for today."))
        }

        val record = currentList[index]
        if (record.checkOutTime != null) {
            return Result.failure(IllegalStateException("Already clocked out at ${record.checkOutTime}."))
        }

        // Calculate hours worked (simulated reasonable shift hours)
        val hoursWorked = 8.2
        val overtime = if (hoursWorked > 8.0) 15 else 0

        val updated = record.copy(
            checkOutTime = currentTime,
            workHours = hoursWorked,
            overtimeMinutes = overtime,
            notes = notes
        )
        currentList[index] = updated
        _attendanceRecords.value = currentList
        return Result.success(updated)
    }

    // LEAVE MANAGEMENT
    fun applyLeave(
        userId: String,
        leaveType: LeaveType,
        startDate: String,
        endDate: String,
        daysCount: Int,
        reason: String
    ): Result<LeaveRequest> {
        val user = userDatabase.find { it.id == userId }
            ?: return Result.failure(IllegalArgumentException("User not found"))

        if (reason.isBlank()) {
            return Result.failure(IllegalArgumentException("Please provide a reason for the leave."))
        }

        val newRequest = LeaveRequest(
            id = "lev_" + UUID.randomUUID().toString().take(8),
            userId = user.id,
            employeeName = user.name,
            employeeCode = user.employeeCode,
            department = user.department,
            leaveType = leaveType,
            startDate = startDate,
            endDate = endDate,
            daysCount = daysCount,
            reason = reason,
            status = LeaveStatus.PENDING,
            appliedAt = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US).format(Date())
        )

        val updated = _leaveRequests.value.toMutableList()
        updated.add(0, newRequest)
        _leaveRequests.value = updated
        return Result.success(newRequest)
    }

    fun reviewLeave(requestId: String, status: LeaveStatus, note: String): Result<LeaveRequest> {
        val adminGuard = RoleGuard.requireAdmin(_currentUser.value)
        if (adminGuard.isFailure) return Result.failure(adminGuard.exceptionOrNull()!!)

        val list = _leaveRequests.value.toMutableList()
        val index = list.indexOfFirst { it.id == requestId }
        if (index < 0) return Result.failure(IllegalArgumentException("Request not found"))

        val currentReq = list[index]
        val updated = currentReq.copy(
            status = status,
            reviewedBy = _currentUser.value?.name ?: "HR Admin",
            reviewNote = note
        )
        list[index] = updated
        _leaveRequests.value = list
        return Result.success(updated)
    }

    // ADMIN DIRECTORY & SETTINGS
    fun getAllEmployees(): List<User> = userDatabase.toList()

    fun addEmployee(
        name: String,
        email: String,
        department: String,
        designation: String,
        role: UserRole
    ): Result<User> {
        val adminGuard = RoleGuard.requireAdmin(_currentUser.value)
        if (adminGuard.isFailure) return Result.failure(adminGuard.exceptionOrNull()!!)

        val initials = name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.joinToString("").take(2).uppercase()
        val newCode = "EMP-${2050 + userDatabase.size}"
        val newUser = User(
            id = "usr_emp_${UUID.randomUUID().toString().take(6)}",
            name = name,
            email = email,
            role = role,
            department = department,
            employeeCode = newCode,
            designation = designation,
            avatarInitials = if (initials.isNotEmpty()) initials else "EM",
            joinDate = dateFormat.format(Date())
        )
        userDatabase.add(newUser)
        return Result.success(newUser)
    }

    fun updateShiftSchedule(newSchedule: ShiftSchedule): Result<Unit> {
        val adminGuard = RoleGuard.requireAdmin(_currentUser.value)
        if (adminGuard.isFailure) return Result.failure(adminGuard.exceptionOrNull()!!)
        _shiftSchedule.value = newSchedule
        return Result.success(Unit)
    }

    // STATS CALCULATIONS
    fun getEmployeeStats(userId: String): EmployeeStats {
        val userRecords = _attendanceRecords.value.filter { it.userId == userId }
        val presentCount = userRecords.count { it.status == AttendanceStatus.PRESENT || it.status == AttendanceStatus.LATE || it.status == AttendanceStatus.HALF_DAY }
        val onTimeCount = userRecords.count { it.status == AttendanceStatus.PRESENT }
        val totalHours = userRecords.sumOf { it.workHours }
        val totalOvertimeMinutes = userRecords.sumOf { it.overtimeMinutes }

        val rate = if (userRecords.isNotEmpty()) (presentCount * 100) / userRecords.size else 100
        val onTimeRate = if (presentCount > 0) (onTimeCount * 100) / presentCount else 100
        val avgHours = if (presentCount > 0) totalHours / presentCount else 8.0

        return EmployeeStats(
            presentDaysThisMonth = presentCount,
            totalWorkDays = maxOf(userRecords.size, 1),
            attendanceRatePercentage = rate,
            onTimeRatePercentage = onTimeRate,
            totalHoursWorked = (totalHours * 10).toInt() / 10.0,
            averageHoursPerDay = (avgHours * 10).toInt() / 10.0,
            overtimeHours = (totalOvertimeMinutes / 60.0 * 10).toInt() / 10.0,
            leavesRemaining = 24
        )
    }

    fun getCompanyStats(): CompanyStats {
        val todayStr = dateFormat.format(Date())
        val todayRecords = _attendanceRecords.value.filter { it.date == todayStr }

        val total = userDatabase.size
        val present = todayRecords.count { it.status == AttendanceStatus.PRESENT }
        val late = todayRecords.count { it.status == AttendanceStatus.LATE }
        val onLeave = todayRecords.count { it.status == AttendanceStatus.ON_LEAVE }
        val absent = total - (present + late + onLeave)
        val pendingLeaves = _leaveRequests.value.count { it.status == LeaveStatus.PENDING }

        val rate = if (total > 0) ((present + late) * 100) / total else 90

        val deptMap = userDatabase.groupBy { it.department }
        val breakdowns = deptMap.map { (dept, members) ->
            val deptPresent = todayRecords.count { record ->
                members.any { it.id == record.userId } && (record.status == AttendanceStatus.PRESENT || record.status == AttendanceStatus.LATE)
            }
            DepartmentMetric(
                name = dept,
                total = members.size,
                present = deptPresent,
                percentage = if (members.isNotEmpty()) (deptPresent * 100) / members.size else 100
            )
        }

        return CompanyStats(
            totalEmployees = total,
            presentToday = present + late,
            lateToday = late,
            onLeaveToday = onLeave,
            absentToday = maxOf(absent, 0),
            pendingLeaveRequests = pendingLeaves,
            averageAttendanceRate = rate,
            departmentBreakdowns = breakdowns
        )
    }
}
