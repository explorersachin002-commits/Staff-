package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.backend.data.AttendanceRepository
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AttendanceViewModel : ViewModel() {
    val currentUser = AttendanceRepository.currentUser
    val authTokens = AttendanceRepository.authTokens
    val attendanceRecords = AttendanceRepository.attendanceRecords
    val leaveRequests = AttendanceRepository.leaveRequests
    val shiftSchedule = AttendanceRepository.shiftSchedule

    // Time ticker for live digital clock & duration
    private val _currentFormattedTime = MutableStateFlow("")
    val currentFormattedTime: StateFlow<String> = _currentFormattedTime.asStateFlow()

    private val _currentFormattedDate = MutableStateFlow("")
    val currentFormattedDate: StateFlow<String> = _currentFormattedDate.asStateFlow()

    // Feedback message state
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Loading states
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        startLiveClockTicker()
    }

    private fun startLiveClockTicker() {
        viewModelScope.launch {
            val timeFmt = SimpleDateFormat("hh:mm:ss a", Locale.US)
            val dateFmt = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US)
            while (true) {
                val now = Date()
                _currentFormattedTime.value = timeFmt.format(now)
                _currentFormattedDate.value = dateFmt.format(now)
                delay(1000)
            }
        }
    }

    fun showMessage(msg: String) {
        _toastMessage.value = msg
        viewModelScope.launch {
            delay(3500)
            if (_toastMessage.value == msg) {
                _toastMessage.value = null
            }
        }
    }

    fun clearMessage() {
        _toastMessage.value = null
    }

    // Role quick-switch
    fun switchRole(role: UserRole) {
        AttendanceRepository.switchActiveDemoUser(role)
        showMessage("Switched view to ${role.name.lowercase().replaceFirstChar { it.uppercase() }} profile.")
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        _isLoading.value = true
        viewModelScope.launch {
            delay(500) // Realistic network sensation
            val result = AttendanceRepository.login(email, pass)
            _isLoading.value = false
            if (result.isSuccess) {
                showMessage("Welcome back, ${result.getOrNull()?.first?.name}!")
                onSuccess()
            } else {
                showMessage(result.exceptionOrNull()?.message ?: "Login failed")
            }
        }
    }

    fun logout() {
        AttendanceRepository.logout()
        showMessage("Logged out successfully.")
    }

    fun punchIn(location: String = "HQ Main Campus (Building A)") {
        val user = currentUser.value ?: return
        _isLoading.value = true
        viewModelScope.launch {
            delay(400)
            val result = AttendanceRepository.clockIn(user.id, location)
            _isLoading.value = false
            if (result.isSuccess) {
                val record = result.getOrNull()!!
                showMessage("Punched in at ${record.checkInTime} (${record.status.name})")
            } else {
                showMessage(result.exceptionOrNull()?.message ?: "Punch in error")
            }
        }
    }

    fun punchOut(notes: String = "Shift completed") {
        val user = currentUser.value ?: return
        _isLoading.value = true
        viewModelScope.launch {
            delay(400)
            val result = AttendanceRepository.clockOut(user.id, notes)
            _isLoading.value = false
            if (result.isSuccess) {
                val record = result.getOrNull()!!
                showMessage("Punched out at ${record.checkOutTime}. Work duration logged.")
            } else {
                showMessage(result.exceptionOrNull()?.message ?: "Punch out error")
            }
        }
    }

    fun applyLeave(
        leaveType: LeaveType,
        startDate: String,
        endDate: String,
        days: Int,
        reason: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        _isLoading.value = true
        viewModelScope.launch {
            delay(400)
            val result = AttendanceRepository.applyLeave(user.id, leaveType, startDate, endDate, days, reason)
            _isLoading.value = false
            if (result.isSuccess) {
                showMessage("Leave request submitted for $days day(s).")
                onSuccess()
            } else {
                showMessage(result.exceptionOrNull()?.message ?: "Error applying leave")
            }
        }
    }

    fun reviewLeave(requestId: String, status: LeaveStatus, note: String) {
        val result = AttendanceRepository.reviewLeave(requestId, status, note)
        if (result.isSuccess) {
            val statusLabel = if (status == LeaveStatus.APPROVED) "Approved" else "Rejected"
            showMessage("Leave request $statusLabel.")
        } else {
            showMessage(result.exceptionOrNull()?.message ?: "Review failed")
        }
    }

    fun addEmployee(name: String, email: String, dept: String, designation: String, role: UserRole, onSuccess: () -> Unit) {
        val result = AttendanceRepository.addEmployee(name, email, dept, designation, role)
        if (result.isSuccess) {
            showMessage("Added new employee ${result.getOrNull()?.name}.")
            onSuccess()
        } else {
            showMessage(result.exceptionOrNull()?.message ?: "Failed to add employee")
        }
    }

    fun updateShift(startTime: String, endTime: String, graceMins: Int) {
        val curr = shiftSchedule.value
        val updated = curr.copy(
            startTime = startTime,
            endTime = endTime,
            gracePeriodMinutes = graceMins
        )
        val res = AttendanceRepository.updateShiftSchedule(updated)
        if (res.isSuccess) {
            showMessage("Shift policy schedule updated successfully.")
        } else {
            showMessage(res.exceptionOrNull()?.message ?: "Update failed")
        }
    }

    fun getEmployeeStats(): EmployeeStats {
        val user = currentUser.value
        return if (user != null) {
            AttendanceRepository.getEmployeeStats(user.id)
        } else {
            EmployeeStats(0, 0, 0, 0, 0.0, 0.0, 0.0, 0)
        }
    }

    fun getCompanyStats(): CompanyStats {
        return AttendanceRepository.getCompanyStats()
    }

    fun getAllEmployees(): List<User> {
        return AttendanceRepository.getAllEmployees()
    }
}
