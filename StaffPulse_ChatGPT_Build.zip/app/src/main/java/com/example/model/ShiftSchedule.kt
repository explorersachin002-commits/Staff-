package com.example.model

data class ShiftSchedule(
    val id: String = "shift_std",
    val name: String = "General Office Shift",
    val startTime: String = "09:00 AM",
    val endTime: String = "05:00 PM",
    val gracePeriodMinutes: Int = 15,
    val halfDayThresholdHours: Double = 4.0,
    val fullDayThresholdHours: Double = 8.0,
    val workDays: String = "Mon - Fri"
)

data class EmployeeStats(
    val presentDaysThisMonth: Int,
    val totalWorkDays: Int,
    val attendanceRatePercentage: Int,
    val onTimeRatePercentage: Int,
    val totalHoursWorked: Double,
    val averageHoursPerDay: Double,
    val overtimeHours: Double,
    val leavesRemaining: Int
)

data class CompanyStats(
    val totalEmployees: Int,
    val presentToday: Int,
    val lateToday: Int,
    val onLeaveToday: Int,
    val absentToday: Int,
    val pendingLeaveRequests: Int,
    val averageAttendanceRate: Int,
    val departmentBreakdowns: List<DepartmentMetric>
)

data class DepartmentMetric(
    val name: String,
    val total: Int,
    val present: Int,
    val percentage: Int
)
