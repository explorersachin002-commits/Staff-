package com.example.model

enum class UserRole {
    EMPLOYEE,
    ADMIN
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val department: String,
    val employeeCode: String,
    val designation: String,
    val avatarInitials: String,
    val joinDate: String,
    val phone: String = "+1 (555) 019-2834",
    val activeShiftId: String = "shift_std",
    val leaveBalanceCasual: Int = 12,
    val leaveBalanceSick: Int = 8,
    val leaveBalanceAnnual: Int = 18
)
