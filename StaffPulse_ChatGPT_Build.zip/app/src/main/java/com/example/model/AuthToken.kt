package com.example.model

data class AuthTokens(
    val accessToken: String,
    val refreshToken: String,
    val tokenType: String = "Bearer",
    val expiresInSeconds: Long = 3600L,
    val issuedAt: Long = System.currentTimeMillis()
) {
    val isExpired: Boolean
        get() = (System.currentTimeMillis() - issuedAt) > (expiresInSeconds * 1000L)
}

data class AuthState(
    val isAuthenticated: Boolean = false,
    val currentUser: User? = null,
    val tokens: AuthTokens? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)
