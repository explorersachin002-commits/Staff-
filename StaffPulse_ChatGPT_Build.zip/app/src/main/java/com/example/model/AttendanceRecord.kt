package com.example.model

enum class AttendanceStatus {
    PRESENT,
    LATE,
    HALF_DAY,
    ON_LEAVE,
    ABSENT
}

data class AttendanceRecord(
    val id: String,
    val userId: String,
    val employeeName: String,
    val employeeCode: String,
    val department: String,
    val date: String, // e.g. "2026-10-12"
    val dayOfWeek: String, // e.g. "Monday"
    val checkInTime: String? = null, // e.g. "09:04 AM"
    val checkOutTime: String? = null, // e.g. "05:15 PM"
    val status: AttendanceStatus,
    val location: String = "HQ Main Campus (Building A)",
    val workHours: Double = 0.0,
    val overtimeMinutes: Int = 0,
    val notes: String = ""
)
