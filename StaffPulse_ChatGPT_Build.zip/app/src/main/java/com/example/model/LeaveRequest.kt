package com.example.model

enum class LeaveType {
    CASUAL,
    SICK,
    ANNUAL,
    COMPENSATORY,
    UNPAID
}

enum class LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class LeaveRequest(
    val id: String,
    val userId: String,
    val employeeName: String,
    val employeeCode: String,
    val department: String,
    val leaveType: LeaveType,
    val startDate: String,
    val endDate: String,
    val daysCount: Int,
    val reason: String,
    val status: LeaveStatus,
    val appliedAt: String,
    val reviewedBy: String? = null,
    val reviewNote: String? = null
)
