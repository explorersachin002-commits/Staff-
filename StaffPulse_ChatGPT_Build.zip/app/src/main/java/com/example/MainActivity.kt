package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.UserRole
import com.example.ui.admin.AdminDashboard
import com.example.ui.auth.LoginScreen
import com.example.ui.employee.EmployeeDashboard
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AttendanceViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: AttendanceViewModel = viewModel()) {
    val currentUser by viewModel.currentUser.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentUser,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "userScreenTransition"
            ) { user ->
                when {
                    user == null -> {
                        LoginScreen(
                            viewModel = viewModel,
                            onLoginSuccess = { /* Session updated reactively */ }
                        )
                    }
                    user.role == UserRole.ADMIN -> {
                        BackHandler {
                            viewModel.switchRole(UserRole.EMPLOYEE)
                        }
                        AdminDashboard(
                            viewModel = viewModel,
                            onLogout = { viewModel.logout() }
                        )
                    }
                    else -> {
                        EmployeeDashboard(
                            viewModel = viewModel,
                            onLogout = { viewModel.logout() }
                        )
                    }
                }
            }

            // Global floating feedback
            if (toastMessage != null) {
                Snackbar(
                    action = {
                        TextButton(onClick = { viewModel.clearMessage() }) {
                            Text("DISMISS", color = Color.White)
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .navigationBarsPadding()
                ) {
                    Text(toastMessage!!)
                }
            }
        }
    }
}
