package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo / Executive Slate Palette
val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Navy700 = Color(0xFF334155)

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueDark = Color(0xFF1D4ED8)
val PrimaryBlueLight = Color(0xFF60A5FA)
val PrimaryBlueContainer = Color(0xFFDBEAFE)

val AccentCyan = Color(0xFF06B6D4)
val AccentTeal = Color(0xFF0D9488)

// Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessContainer = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusError = Color(0xFFEF4444)
val StatusErrorContainer = Color(0xFFFEE2E2)
val StatusInfo = Color(0xFF3B82F6)
val StatusInfoContainer = Color(0xFFDBEAFE)
val StatusPurple = Color(0xFF8B5CF6)
val StatusPurpleContainer = Color(0xFFEDE9FE)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val BackgroundLight = Color(0xFFF8FAFC)
val OutlineLight = Color(0xFFE2E8F0)

val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val BackgroundDark = Color(0xFF0F172A)
val OutlineDark = Color(0xFF475569)
