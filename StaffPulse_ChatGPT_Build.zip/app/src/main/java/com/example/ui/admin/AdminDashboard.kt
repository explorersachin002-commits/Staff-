package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.AttendanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboard(
    viewModel: AttendanceViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showAddEmployeeDialog by remember { mutableStateOf(false) }
    var showShiftDialog by remember { mutableStateOf(false) }
    var reviewingRequest by remember { mutableStateOf<LeaveRequest?>(null) }

    val user by viewModel.currentUser.collectAsState()
    val records by viewModel.attendanceRecords.collectAsState()
    val leaveRequests by viewModel.leaveRequests.collectAsState()
    val shiftSchedule by viewModel.shiftSchedule.collectAsState()

    val adminUser = user ?: return
    val companyStats = remember(records, leaveRequests) {
        viewModel.getCompanyStats()
    }
    val allEmployees = remember(records) {
        viewModel.getAllEmployees()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            initials = adminUser.avatarInitials,
                            size = 38.dp,
                            backgroundColor = PrimaryBlueDark
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = adminUser.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = PrimaryBlueContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "HR ADMIN",
                                        color = PrimaryBlue,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Workforce & Attendance Center",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    AssistChip(
                        onClick = { viewModel.switchRole(UserRole.EMPLOYEE) },
                        label = { Text("Employee View", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = PrimaryBlue
                            )
                        },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("switch_to_emp_chip")
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            val pendingLeavesCount = leaveRequests.count { it.status == LeaveStatus.PENDING }
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("admin_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            if (selectedTab == 0) Icons.Filled.People else Icons.Outlined.People,
                            contentDescription = "Live Roster"
                        )
                    },
                    label = { Text("Live Roster") },
                    modifier = Modifier.testTag("tab_admin_roster")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (pendingLeavesCount > 0) {
                                    Badge { Text("$pendingLeavesCount") }
                                }
                            }
                        ) {
                            Icon(
                                if (selectedTab == 1) Icons.Filled.Approval else Icons.Outlined.Approval,
                                contentDescription = "Approvals"
                            )
                        }
                    },
                    label = { Text("Approvals") },
                    modifier = Modifier.testTag("tab_admin_approvals")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        Icon(
                            if (selectedTab == 2) Icons.Filled.Badge else Icons.Outlined.Badge,
                            contentDescription = "Team"
                        )
                    },
                    label = { Text("Directory") },
                    modifier = Modifier.testTag("tab_admin_directory")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = {
                        Icon(
                            if (selectedTab == 3) Icons.Filled.Analytics else Icons.Outlined.Analytics,
                            contentDescription = "Settings"
                        )
                    },
                    label = { Text("Analytics") },
                    modifier = Modifier.testTag("tab_admin_analytics")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> LiveRosterScreen(
                    records = records.filter { it.date.contains("2026") },
                    companyStats = companyStats
                )
                1 -> LeaveApprovalsScreen(
                    requests = leaveRequests,
                    onReviewClick = { req -> reviewingRequest = req }
                )
                2 -> DirectoryScreen(
                    employees = allEmployees,
                    onAddClick = { showAddEmployeeDialog = true }
                )
                3 -> AnalyticsSettingsScreen(
                    companyStats = companyStats,
                    shiftSchedule = shiftSchedule,
                    onEditShiftClick = { showShiftDialog = true },
                    onLogout = onLogout
                )
            }
        }
    }

    if (showAddEmployeeDialog) {
        AddEmployeeDialog(
            onDismiss = { showAddEmployeeDialog = false },
            onAdd = { name, email, dept, desig, role ->
                viewModel.addEmployee(name, email, dept, desig, role) {
                    showAddEmployeeDialog = false
                }
            }
        )
    }

    if (showShiftDialog) {
        ShiftSettingsDialog(
            currentSchedule = shiftSchedule,
            onDismiss = { showShiftDialog = false },
            onSave = { start, end, grace ->
                viewModel.updateShift(start, end, grace)
                showShiftDialog = false
            }
        )
    }

    if (reviewingRequest != null) {
        LeaveReviewDialog(
            request = reviewingRequest!!,
            onDismiss = { reviewingRequest = null },
            onReview = { status, note ->
                viewModel.reviewLeave(reviewingRequest!!.id, status, note)
                reviewingRequest = null
            }
        )
    }
}

@Composable
private fun LiveRosterScreen(
    records: List<AttendanceRecord>,
    companyStats: CompanyStats
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf<AttendanceStatus?>(null) }

    val filteredRecords = remember(records, searchQuery, selectedFilter) {
        records.filter { rec ->
            val matchesQuery = searchQuery.isBlank() ||
                    rec.employeeName.contains(searchQuery, ignoreCase = true) ||
                    rec.department.contains(searchQuery, ignoreCase = true) ||
                    rec.employeeCode.contains(searchQuery, ignoreCase = true)
            val matchesStatus = selectedFilter == null || rec.status == selectedFilter
            matchesQuery && matchesStatus
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Stats Overview Row
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = "Present",
                    value = "${companyStats.presentToday}",
                    subtitle = "${companyStats.averageAttendanceRate}% rate",
                    icon = Icons.Default.CheckCircle,
                    iconTint = StatusSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Late",
                    value = "${companyStats.lateToday}",
                    subtitle = "Past grace",
                    icon = Icons.Default.AccessTime,
                    iconTint = StatusWarning,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "On Leave",
                    value = "${companyStats.onLeaveToday}",
                    subtitle = "Approved",
                    icon = Icons.Default.EventBusy,
                    iconTint = StatusInfo,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Absent",
                    value = "${companyStats.absentToday}",
                    subtitle = "Unreported",
                    icon = Icons.Default.Cancel,
                    iconTint = StatusError,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search employee by name, ID or department...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_search_input")
            )
        }

        // Filter Chips
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    label = { Text("All (${records.size})") }
                )
                FilterChip(
                    selected = selectedFilter == AttendanceStatus.PRESENT,
                    onClick = { selectedFilter = AttendanceStatus.PRESENT },
                    label = { Text("Present") }
                )
                FilterChip(
                    selected = selectedFilter == AttendanceStatus.LATE,
                    onClick = { selectedFilter = AttendanceStatus.LATE },
                    label = { Text("Late") }
                )
                FilterChip(
                    selected = selectedFilter == AttendanceStatus.ON_LEAVE,
                    onClick = { selectedFilter = AttendanceStatus.ON_LEAVE },
                    label = { Text("On Leave") }
                )
            }
        }

        // Employees List
        items(filteredRecords, key = { it.id }) { record ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = record.employeeName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = record.employeeCode,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = record.department,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (record.checkInTime != null) "In: ${record.checkInTime}" else "No punch yet",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            if (record.location.isNotBlank()) {
                                Text(
                                    text = " • ${record.location}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    StatusBadge(status = record.status)
                }
            }
        }
    }
}

@Composable
private fun LeaveApprovalsScreen(
    requests: List<LeaveRequest>,
    onReviewClick: (LeaveRequest) -> Unit
) {
    val pending = requests.filter { it.status == LeaveStatus.PENDING }
    val reviewed = requests.filter { it.status != LeaveStatus.PENDING }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "Pending Leave Requests (${pending.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (pending.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp)
                    ) {
                        Icon(
                            Icons.Default.TaskAlt,
                            contentDescription = null,
                            tint = StatusSuccess,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("All Caught Up!", fontWeight = FontWeight.Bold)
                        Text("No pending leave applications requiring approval.", fontSize = 13.sp, color = Color.Gray)
                    }
                }
            }
        } else {
            items(pending, key = { it.id }) { req ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = req.employeeName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "${req.employeeCode} • ${req.department}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            LeaveStatusBadge(status = req.status)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "${req.leaveType.name} Leave • ${req.startDate} to ${req.endDate} (${req.daysCount} days)",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "\"${req.reason}\"",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { onReviewClick(req) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("review_leave_${req.id}")
                            ) {
                                Text("Review & Decide")
                            }
                        }
                    }
                }
            }
        }

        if (reviewed.isNotEmpty()) {
            item {
                Text(
                    text = "Decision History (${reviewed.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            items(reviewed, key = { it.id }) { req ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "${req.employeeName} (${req.leaveType.name})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${req.startDate} (${req.daysCount}d) • ${req.reviewedBy ?: "HR"}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        LeaveStatusBadge(status = req.status)
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectoryScreen(
    employees: List<User>,
    onAddClick: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Staff Directory (${employees.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("add_employee_btn")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Member")
                }
            }
        }

        items(employees, key = { it.id }) { emp ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    UserAvatar(
                        initials = emp.avatarInitials,
                        size = 46.dp,
                        backgroundColor = if (emp.role == UserRole.ADMIN) PrimaryBlueDark else PrimaryBlue
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = emp.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            if (emp.role == UserRole.ADMIN) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = PrimaryBlueContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "ADMIN",
                                        color = PrimaryBlue,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${emp.designation} • ${emp.department}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${emp.employeeCode} • ${emp.email}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyticsSettingsScreen(
    companyStats: CompanyStats,
    shiftSchedule: ShiftSchedule,
    onEditShiftClick: () -> Unit,
    onLogout: () -> Unit
) {
    var showReportExportedModal by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Shift Configuration Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "Standard Office Shift",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${shiftSchedule.workDays} • Standard policy",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = onEditShiftClick,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("edit_shift_policy_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit")
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Hours:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text("${shiftSchedule.startTime} – ${shiftSchedule.endTime}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Grace Period:", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text("${shiftSchedule.gracePeriodMinutes} Minutes", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Department Attendance Breakdown
        item {
            Text(
                text = "Department Attendance Rates",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    companyStats.departmentBreakdowns.forEach { dept ->
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(dept.name, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                Text("${dept.present}/${dept.total} (${dept.percentage}%)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { dept.percentage / 100f },
                                color = if (dept.percentage >= 80) StatusSuccess else StatusWarning,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Export Report Button
        item {
            Button(
                onClick = { showReportExportedModal = true },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("export_attendance_report_btn")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export Monthly Attendance Summary (CSV)")
            }
        }

        // Sign Out
        item {
            OutlinedButton(
                onClick = onLogout,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out from Admin Console")
            }
        }
    }

    if (showReportExportedModal) {
        AlertDialog(
            onDismissRequest = { showReportExportedModal = false },
            title = { Text("Attendance Summary Exported") },
            text = {
                Text("Successfully generated Attendance_Report_${System.currentTimeMillis().toString().takeLast(6)}.csv with ${companyStats.totalEmployees} employee logs.")
            },
            confirmButton = {
                TextButton(onClick = { showReportExportedModal = false }) {
                    Text("Done")
                }
            }
        )
    }
}
