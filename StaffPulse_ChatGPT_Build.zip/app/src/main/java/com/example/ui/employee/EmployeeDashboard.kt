package com.example.ui.employee

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.AttendanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeDashboard(
    viewModel: AttendanceViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showApplyLeaveDialog by remember { mutableStateOf(false) }

    val user by viewModel.currentUser.collectAsState()
    val records by viewModel.attendanceRecords.collectAsState()
    val leaveRequests by viewModel.leaveRequests.collectAsState()
    val shiftSchedule by viewModel.shiftSchedule.collectAsState()
    val currentTime by viewModel.currentFormattedTime.collectAsState()
    val currentDate by viewModel.currentFormattedDate.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    val currentEmployee = user ?: return

    // Find today's record
    val todayRecord = records.firstOrNull { it.userId == currentEmployee.id && it.date.contains("2026") }
    val isClockedIn = todayRecord?.checkInTime != null && todayRecord.checkOutTime == null
    val isShiftCompleted = todayRecord?.checkInTime != null && todayRecord.checkOutTime != null

    val stats = remember(records, currentEmployee.id) {
        viewModel.getEmployeeStats()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            initials = currentEmployee.avatarInitials,
                            size = 38.dp,
                            backgroundColor = PrimaryBlue
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = currentEmployee.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${currentEmployee.employeeCode} • ${currentEmployee.department}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // Quick Switch to Admin mode button for testing
                    AssistChip(
                        onClick = { viewModel.switchRole(UserRole.ADMIN) },
                        label = { Text("Admin View", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = PrimaryBlue
                            )
                        },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("switch_to_admin_chip")
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("employee_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            if (selectedTab == 0) Icons.Filled.Fingerprint else Icons.Outlined.Fingerprint,
                            contentDescription = "Punch Clock"
                        )
                    },
                    label = { Text("Punch") },
                    modifier = Modifier.testTag("tab_punch")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        Icon(
                            if (selectedTab == 1) Icons.Filled.DateRange else Icons.Outlined.DateRange,
                            contentDescription = "History"
                        )
                    },
                    label = { Text("Timesheet") },
                    modifier = Modifier.testTag("tab_timesheet")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        Icon(
                            if (selectedTab == 2) Icons.Filled.EventBusy else Icons.Outlined.EventBusy,
                            contentDescription = "Leaves"
                        )
                    },
                    label = { Text("Leaves") },
                    modifier = Modifier.testTag("tab_leaves")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = {
                        Icon(
                            if (selectedTab == 3) Icons.Filled.Person else Icons.Outlined.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = { Text("Profile") },
                    modifier = Modifier.testTag("tab_profile")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> PunchScreen(
                    employee = currentEmployee,
                    todayRecord = todayRecord,
                    isClockedIn = isClockedIn,
                    isShiftCompleted = isShiftCompleted,
                    shiftSchedule = shiftSchedule,
                    currentTime = currentTime,
                    currentDate = currentDate,
                    stats = stats,
                    isLoading = isLoading,
                    onPunchIn = { viewModel.punchIn() },
                    onPunchOut = { viewModel.punchOut() },
                    onNavigateToHistory = { selectedTab = 1 },
                    onNavigateToLeaves = { selectedTab = 2 }
                )
                1 -> TimesheetScreen(
                    records = records.filter { it.userId == currentEmployee.id },
                    stats = stats
                )
                2 -> LeavesScreen(
                    employee = currentEmployee,
                    requests = leaveRequests.filter { it.userId == currentEmployee.id },
                    onApplyClick = { showApplyLeaveDialog = true }
                )
                3 -> ProfileScreen(
                    employee = currentEmployee,
                    shiftSchedule = shiftSchedule,
                    onLogout = onLogout,
                    onSwitchRole = { viewModel.switchRole(UserRole.ADMIN) }
                )
            }
        }
    }

    if (showApplyLeaveDialog) {
        ApplyLeaveDialog(
            onDismiss = { showApplyLeaveDialog = false },
            onSubmit = { type, start, end, days, reason ->
                viewModel.applyLeave(type, start, end, days, reason) {
                    showApplyLeaveDialog = false
                }
            }
        )
    }
}

@Composable
private fun PunchScreen(
    employee: User,
    todayRecord: AttendanceRecord?,
    isClockedIn: Boolean,
    isShiftCompleted: Boolean,
    shiftSchedule: ShiftSchedule,
    currentTime: String,
    currentDate: String,
    stats: EmployeeStats,
    isLoading: Boolean,
    onPunchIn: () -> Unit,
    onPunchOut: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToLeaves: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Digital Clock Hero Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Navy900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp, horizontal = 20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        PulseIndicator(isActive = isClockedIn, color = if (isClockedIn) StatusSuccess else Color.Gray)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isClockedIn) "CURRENTLY CLOCKED IN" else if (isShiftCompleted) "SHIFT COMPLETED" else "NOT CLOCKED IN",
                            color = if (isClockedIn) StatusSuccess else Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (currentTime.isNotBlank()) currentTime else "09:00:00 AM",
                        color = Color.White,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = if (currentDate.isNotBlank()) currentDate else "Today",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Office Location Badge
                    Surface(
                        color = Color.White.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Location",
                                tint = PrimaryBlueLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "HQ Main Campus (Building A) • Verified GPS",
                                color = Color(0xFFE2E8F0),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Punch Action Button Area
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Shift: ${shiftSchedule.startTime} – ${shiftSchedule.endTime}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Grace period: ${shiftSchedule.gracePeriodMinutes} mins • Overtime tracked automatically",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Big Circular Punch Button
                    val buttonColor by animateColorAsState(
                        targetValue = when {
                            isClockedIn -> StatusWarning
                            isShiftCompleted -> StatusSuccess
                            else -> PrimaryBlue
                        },
                        label = "btnColor"
                    )

                    Button(
                        onClick = {
                            if (isClockedIn) {
                                onPunchOut()
                            } else if (!isShiftCompleted) {
                                onPunchIn()
                            }
                        },
                        enabled = !isLoading && !isShiftCompleted,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                        modifier = Modifier
                            .size(140.dp)
                            .testTag("punch_action_button")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp))
                            } else {
                                Icon(
                                    imageVector = when {
                                        isClockedIn -> Icons.Default.Logout
                                        isShiftCompleted -> Icons.Default.Check
                                        else -> Icons.Default.Fingerprint
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = when {
                                        isClockedIn -> "Clock Out"
                                        isShiftCompleted -> "Completed"
                                        else -> "Clock In"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Today's Check In / Check Out details
                    Row(
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Punch In", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = todayRecord?.checkInTime ?: "--:--",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (todayRecord?.checkInTime != null) StatusSuccess else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        VerticalDivider(modifier = Modifier.height(34.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Punch Out", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = todayRecord?.checkOutTime ?: "--:--",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (todayRecord?.checkOutTime != null) StatusInfo else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        VerticalDivider(modifier = Modifier.height(34.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Work Hours", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = if (todayRecord != null && todayRecord.workHours > 0) "${todayRecord.workHours}h" else "--",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // Quick Stats Row
        item {
            Text(
                text = "Performance Overview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = "Present Days",
                    value = "${stats.presentDaysThisMonth}/${stats.totalWorkDays}",
                    subtitle = "${stats.attendanceRatePercentage}% rate",
                    icon = Icons.Default.EventAvailable,
                    iconTint = StatusSuccess,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToHistory
                )
                MetricCard(
                    title = "On-Time Rate",
                    value = "${stats.onTimeRatePercentage}%",
                    subtitle = "Within grace",
                    icon = Icons.Default.Timer,
                    iconTint = PrimaryBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Leave Left",
                    value = "${stats.leavesRemaining}d",
                    subtitle = "Annual pool",
                    icon = Icons.Default.BeachAccess,
                    iconTint = StatusWarning,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToLeaves
                )
            }
        }
    }
}

@Composable
private fun TimesheetScreen(
    records: List<AttendanceRecord>,
    stats: EmployeeStats
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Total Logged", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${stats.totalHoursWorked} hrs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Average / Day", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${stats.averageHoursPerDay} hrs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Overtime", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${stats.overtimeHours} hrs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = StatusSuccess)
                    }
                }
            }
        }

        item {
            Text(
                text = "Attendance Log History (${records.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(records, key = { it.id }) { record ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = record.date,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = record.dayOfWeek,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AccessTime,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${record.checkInTime ?: "--"} → ${record.checkOutTime ?: "--"}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (record.workHours > 0) {
                                Text(
                                    text = "  •  ${record.workHours}h",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    StatusBadge(status = record.status)
                }
            }
        }
    }
}

@Composable
private fun LeavesScreen(
    employee: User,
    requests: List<LeaveRequest>,
    onApplyClick: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Leave Balances",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onApplyClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("apply_leave_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Apply Leave")
                }
            }
        }

        // Leave Balance Cards
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = "Casual",
                    value = "${employee.leaveBalanceCasual}d",
                    subtitle = "Remaining",
                    icon = Icons.Default.WbSunny,
                    iconTint = StatusWarning,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Sick",
                    value = "${employee.leaveBalanceSick}d",
                    subtitle = "Remaining",
                    icon = Icons.Default.LocalHospital,
                    iconTint = StatusError,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Annual",
                    value = "${employee.leaveBalanceAnnual}d",
                    subtitle = "Remaining",
                    icon = Icons.Default.FlightTakeoff,
                    iconTint = PrimaryBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text(
                text = "Applied Requests (${requests.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (requests.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.EventAvailable,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No leave requests found", fontWeight = FontWeight.SemiBold)
                        Text("Apply for time off when you need sick or casual days.", fontSize = 13.sp, color = Color.Gray)
                    }
                }
            }
        } else {
            items(requests, key = { it.id }) { req ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = "${req.leaveType.name.lowercase().replaceFirstChar { it.uppercase() }} Leave (${req.daysCount} day${if (req.daysCount > 1) "s" else ""})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${req.startDate}  →  ${req.endDate}",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            LeaveStatusBadge(status = req.status)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "\"${req.reason}\"",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (req.reviewNote != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Comment,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = PrimaryBlue
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${req.reviewedBy}: ${req.reviewNote}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    employee: User,
    shiftSchedule: ShiftSchedule,
    onLogout: () -> Unit,
    onSwitchRole: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // ID Badge Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    UserAvatar(
                        initials = employee.avatarInitials,
                        size = 72.dp,
                        backgroundColor = PrimaryBlue
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = employee.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = employee.designation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = employee.department,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Employee Code", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(employee.employeeCode, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Work Email", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(employee.email, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Phone", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(employee.phone, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Joined Date", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(employee.joinDate, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Assigned Shift", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text("${shiftSchedule.startTime} – ${shiftSchedule.endTime}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                }
            }
        }

        // Action Options
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    ListItem(
                        headlineContent = { Text("Switch to Admin Dashboard") },
                        supportingContent = { Text("Simulate HR & manager role") },
                        leadingContent = {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = PrimaryBlue)
                        },
                        trailingContent = {
                            Icon(Icons.Default.ChevronRight, contentDescription = null)
                        },
                        modifier = Modifier
                            .clickable { onSwitchRole() }
                            .testTag("profile_switch_to_admin")
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text("Sign Out", color = MaterialTheme.colorScheme.error) },
                        supportingContent = { Text("End current session") },
                        leadingContent = {
                            Icon(Icons.Default.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        },
                        modifier = Modifier
                            .clickable { onLogout() }
                            .testTag("profile_logout_btn")
                    )
                }
            }
        }
    }
}
