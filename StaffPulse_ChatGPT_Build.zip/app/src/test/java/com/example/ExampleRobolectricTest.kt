package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.backend.data.AttendanceRepository
import com.example.model.AttendanceStatus
import com.example.model.UserRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches StaffPulse`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("StaffPulse", appName)
    }

    @Test
    fun `test employee login and repository state`() {
        val loginResult = AttendanceRepository.login("alex@company.com", "employee123")
        assertTrue(loginResult.isSuccess)
        val user = loginResult.getOrNull()?.first
        assertNotNull(user)
        assertEquals(UserRole.EMPLOYEE, user?.role)
        assertEquals("EMP-2045", user?.employeeCode)
    }

    @Test
    fun `test admin login and company stats calculation`() {
        val loginResult = AttendanceRepository.login("admin@company.com", "admin123")
        assertTrue(loginResult.isSuccess)
        val stats = AttendanceRepository.getCompanyStats()
        assertTrue(stats.totalEmployees > 0)
        assertTrue(stats.presentToday > 0)
    }
}
