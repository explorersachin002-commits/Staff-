import Geofence from '../models/Geofence.js';
import { haversineDistance } from '../utils/geo.js';

export async function validateGeofence(userId, lat, lng) {
  // Get all active geofences (Phase 2: global; Phase 3: filter by assignedGeofences)
  const geofences = await Geofence.find({ isActive: true });

  if (geofences.length === 0) {
    return { inside: false, distance: Infinity, geofence: null, reason: 'No active geofence configured' };
  }

  const results = geofences.map((gf) => {
    const [gfLng, gfLat] = gf.location.coordinates;
    const distance = haversineDistance(lat, lng, gfLat, gfLng);
    return { geofence: gf, distance, inside: distance <= gf.radiusMeters };
  });

  const closest = results.sort((a, b) => a.distance - b.distance)[0];

  return {
    inside: closest.inside,
    distance: closest.distance,
    geofence: closest.geofence,
    reason: closest.inside
      ? 'Inside geofence'
      : `You are ${Math.round(closest.distance)}m away from the nearest location (max ${closest.geofence.radiusMeters}m)`,
  };
}
