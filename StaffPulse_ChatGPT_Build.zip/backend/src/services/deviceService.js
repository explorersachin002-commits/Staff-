import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { sendDeviceOtpEmail } from './emailService.js';

const OTP_TTL_MS = 10 * 60 * 1000; // 10 minutes
const MAX_OTP_ATTEMPTS = 5;

/**
 * Called at check-in time. Returns { allowed, reason, requiresOtp }.
 */
export async function checkDeviceBinding(userId, incomingDeviceId) {
  const user = await User.findById(userId);

  // First device ever — bind and allow
  if (!user.trustedDeviceId) {
    user.trustedDeviceId = incomingDeviceId;
    await user.save();
    return { allowed: true, reason: 'First device bound' };
  }

  // Match — allow
  if (user.trustedDeviceId === incomingDeviceId) {
    return { allowed: true, reason: 'Trusted device' };
  }

  // Mismatch — require OTP
  return {
    allowed: false,
    reason: 'New device detected. OTP verification required.',
    requiresOtp: true,
  };
}

/**
 * Generate a 6-digit OTP for rebinding to a new device.
 */
export async function requestDeviceRebind(userId, newDeviceId, ip) {
  const user = await User.findById(userId);
  if (!user) throw new Error('User not found');

  const otp = String(crypto.randomInt(100000, 999999));
  const otpHash = await bcrypt.hash(otp, 10);

  user.deviceBindingOtpHash = otpHash;
  user.deviceBindingOtpExpiry = new Date(Date.now() + OTP_TTL_MS);
  user.deviceBindingNewDeviceId = newDeviceId;
  user.deviceBindingOtpAttempts = 0;
  await user.save();

  await sendDeviceOtpEmail(user.email, otp);

  return { sent: true, expiresIn: OTP_TTL_MS / 1000 };
}

/**
 * Verify the OTP and rebind the device.
 */
export async function verifyDeviceRebind(userId, otp) {
  const user = await User.findById(userId)
    .select('+deviceBindingOtpHash +deviceBindingNewDeviceId +deviceBindingOtpExpiry');

  if (!user.deviceBindingOtpHash || !user.deviceBindingNewDeviceId) {
    throw new Error('No pending device binding request');
  }

  if (user.deviceBindingOtpExpiry < new Date()) {
    throw new Error('OTP expired. Request a new one.');
  }

  if (user.deviceBindingOtpAttempts >= MAX_OTP_ATTEMPTS) {
    throw new Error('Too many failed attempts. Request a new OTP.');
  }

  const valid = await bcrypt.compare(otp, user.deviceBindingOtpHash);
  if (!valid) {
    user.deviceBindingOtpAttempts += 1;
    await user.save();
    throw new Error(`Invalid OTP. ${MAX_OTP_ATTEMPTS - user.deviceBindingOtpAttempts} attempts remaining.`);
  }

  // Success — rebind
  const newDeviceId = user.deviceBindingNewDeviceId;
  user.trustedDeviceId = newDeviceId;
  user.deviceBindingOtpHash = null;
  user.deviceBindingOtpExpiry = null;
  user.deviceBindingNewDeviceId = null;
  user.deviceBindingOtpAttempts = 0;
  await user.save();

  return { success: true, deviceId: newDeviceId };
}
