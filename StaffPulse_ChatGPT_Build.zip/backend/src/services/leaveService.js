import LeaveRequest from '../models/LeaveRequest.js';
import Attendance from '../models/Attendance.js';
import { auditLog } from './auditService.js';
import { sendPushToUser } from './pushService.js';

function eachDateInRange(fromDate, toDate) {
  const dates = [];
  const start = new Date(fromDate);
  const end = new Date(toDate);
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    dates.push(d.toISOString().split('T')[0]);
  }
  return dates;
}

export async function createLeaveRequest(userId, payload) {
  const { type, fromDate, toDate, reason } = payload;

  if (new Date(fromDate) > new Date(toDate)) {
    const err = new Error('fromDate must be before toDate');
    err.status = 400;
    throw err;
  }

  const days = eachDateInRange(fromDate, toDate).length;

  // Overlap check
  const overlap = await LeaveRequest.findOne({
    userId,
    status: { $in: ['pending', 'approved'] },
    $or: [
      { fromDate: { $lte: toDate }, toDate: { $gte: fromDate } },
    ],
  });
  if (overlap) {
    const err = new Error('You already have a leave request overlapping these dates');
    err.status = 409;
    throw err;
  }

  return LeaveRequest.create({ userId, type, fromDate, toDate, days, reason });
}

export async function reviewLeaveRequest({ leaveId, adminId, decision, note }) {
  const leave = await LeaveRequest.findById(leaveId);
  if (!leave) throw new Error('Leave request not found');
  if (leave.status !== 'pending') throw new Error('Leave request already reviewed');

  leave.status = decision; // 'approved' or 'rejected'
  leave.reviewedBy = adminId;
  leave.reviewedAt = new Date();
  leave.reviewNote = note || '';
  await leave.save();

  // On approval, mark attendance days as 'leave'
  if (decision === 'approved') {
    const dates = eachDateInRange(leave.fromDate, leave.toDate);
    for (const date of dates) {
      await Attendance.findOneAndUpdate(
        { userId: leave.userId, date },
        { $setOnInsert: { userId: leave.userId, date, status: 'leave' } },
        { upsert: true }
      );
    }
  }

  await auditLog({
    actorId: adminId,
    action: `LEAVE_${decision.toUpperCase()}`,
    targetType: 'LeaveRequest',
    targetId: leave._id,
    newValue: { decision, note },
  });

  // Notify employee
  sendPushToUser(leave.userId, {
    title: decision === 'approved' ? '✅ Leave Approved' : '❌ Leave Rejected',
    body: `${leave.fromDate} → ${leave.toDate}${note ? ` · ${note}` : ''}`,
    data: { screen: 'leave' },
  }).catch(() => {});

  return leave;
}
