import Settings from '../models/Settings.js';

export async function getSettings() {
  let s = await Settings.findById('global');
  if (!s) {
    s = await Settings.create({ _id: 'global' });
  }
  return s;
}

export async function updateSettings(updates, updatedById) {
  let s = await Settings.findById('global');
  if (!s) {
    s = new Settings({ _id: 'global' });
  }
  Object.assign(s, updates, { updatedBy: updatedById });
  await s.save();
  return s.toObject();
}
