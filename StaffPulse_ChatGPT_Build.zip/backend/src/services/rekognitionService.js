import {
  RekognitionClient,
  CreateCollectionCommand,
  IndexFacesCommand,
  CreateUserCommand,
  AssociateFacesCommand,
  SearchUsersByImageCommand,
} from '@aws-sdk/client-rekognition';

const rekognition = new RekognitionClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const COLLECTION_ID = process.env.REKOGNITION_COLLECTION_ID;
const THRESHOLD = parseInt(process.env.FACE_MATCH_THRESHOLD || '85', 10);

/** Run once to create the collection */
export async function ensureCollection() {
  try {
    await rekognition.send(
      new CreateCollectionCommand({ CollectionId: COLLECTION_ID })
    );
    console.log('Rekognition collection created:', COLLECTION_ID);
  } catch (err) {
    if (err.name === 'ResourceAlreadyExistsException') return;
    throw err;
  }
}

/**
 * Enroll a user's face. Called once per employee.
 * Indexes the face and associates it with a Rekognition User.
 */
export async function enrollFace(userId, base64Image) {
  const buffer = Buffer.from(
    base64Image.replace(/^data:image\/\w+;base64,/, ''),
    'base64'
  );

  // 1. Index face into collection
  const indexResult = await rekognition.send(
    new IndexFacesCommand({
      CollectionId: COLLECTION_ID,
      Image: { Bytes: buffer },
      MaxFaces: 1,
      QualityFilter: 'AUTO', // rejects blurry/angled faces
      DetectionAttributes: ['DEFAULT'],
    })
  );

  if (!indexResult.FaceRecords?.length) {
    throw new Error('No face detected or image quality too low');
  }

  const faceId = indexResult.FaceRecords[0].Face.FaceId;

  // 2. Create Rekognition User for this employee
  try {
    await rekognition.send(
      new CreateUserCommand({
        CollectionId: COLLECTION_ID,
        UserId: userId,
      })
    );
  } catch (err) {
    if (err.name !== 'ResourceAlreadyExistsException') throw err;
  }

  // 3. Associate the face vector with the user
  await rekognition.send(
    new AssociateFacesCommand({
      CollectionId: COLLECTION_ID,
      UserId: userId,
      FaceIds: [faceId],
      UserMatchThreshold: 90,
    })
  );

  return { faceId, collectionId: COLLECTION_ID };
}

/**
 * Verify a selfie against the enrolled user.
 * Returns { matched, score }.
 */
export async function verifyFace(userId, base64Image) {
  const buffer = Buffer.from(
    base64Image.replace(/^data:image\/\w+;base64,/, ''),
    'base64'
  );

  const result = await rekognition.send(
    new SearchUsersByImageCommand({
      CollectionId: COLLECTION_ID,
      Image: { Bytes: buffer },
      UserMatchThreshold: THRESHOLD,
      MaxUsers: 1,
    })
  );

  const match = result.UserMatches?.[0];

  if (!match) {
    return { matched: false, score: 0 };
  }

  // Confirm it's the correct user
  const isSameUser = match.User.UserId === userId;

  return {
    matched: isSameUser,
    score: match.Similarity || 0,
    rekognitionUserId: match.User.UserId,
  };
}
