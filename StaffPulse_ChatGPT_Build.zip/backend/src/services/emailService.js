import nodemailer from 'nodemailer';
import fs from 'fs/promises';
import path from 'path';
import handlebars from 'handlebars';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'email-smtp.us-east-1.amazonaws.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const templateCache = new Map();

async function renderTemplate(name, data) {
  if (!templateCache.has(name)) {
    const filePath = path.join(__dirname, '..', 'templates', `${name}.hbs`);
    const source = await fs.readFile(filePath, 'utf-8');
    templateCache.set(name, handlebars.compile(source));
  }
  return templateCache.get(name)(data);
}

export async function sendEmail({ to, subject, template, data, html }) {
  const content = html || (await renderTemplate(template, data));
  if (!process.env.SMTP_USER || process.env.SMTP_USER.includes('...')) {
    console.log(`[EMAIL SIMULATION] To: ${to} | Subject: "${subject}"`);
    return { messageId: `mock-${Date.now()}` };
  }
  return transporter.sendMail({
    from: process.env.SMTP_FROM || 'Attendance System <no-reply@yourcompany.com>',
    to,
    subject,
    html: content,
  });
}

export async function sendDeviceOtpEmail(email, otp, expiresInMinutes = 10) {
  return sendEmail({
    to: email,
    subject: 'Your device verification code',
    template: 'device-otp',
    data: { otp, expiresInMinutes },
  });
}

export async function sendWeeklyReport(email, { week, rows, summary }) {
  return sendEmail({
    to: email,
    subject: `Weekly Attendance Report — ${week}`,
    template: 'weekly-report',
    data: { week, rows, summary },
  });
}
