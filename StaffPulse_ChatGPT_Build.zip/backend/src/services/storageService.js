import * as s3Service from './s3Service.js';

/**
 * Upload selfie to S3 if configured, or return simulated S3 key in local dev
 */
export async function uploadSelfie(base64Data, key) {
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY && process.env.S3_BUCKET_NAME) {
    return s3Service.uploadSelfie(base64Data, key);
  }

  // Graceful development storage fallback
  return key;
}

export async function getSignedSelfieUrl(key, expiresIn = 900) {
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY && process.env.S3_BUCKET_NAME) {
    return s3Service.getSignedSelfieUrl(key, expiresIn);
  }

  return `https://storage.local/${key}`;
}

export async function deleteSelfie(key) {
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY && process.env.S3_BUCKET_NAME) {
    return s3Service.deleteSelfie(key);
  }
}
