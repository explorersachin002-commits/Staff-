import AuditLog from '../models/AuditLog.js';

export async function auditLog({
  actorId,
  action,
  targetType = null,
  targetId = null,
  oldValue = null,
  newValue = null,
  ipAddress = null,
  userAgent = null,
}) {
  try {
    await AuditLog.create({
      actorId,
      action,
      targetType,
      targetId,
      oldValue,
      newValue,
      ipAddress,
      userAgent,
    });
  } catch (err) {
    console.error('Audit log failed:', err.message); // never block the main flow
  }
}
