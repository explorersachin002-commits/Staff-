import * as rekognitionService from './rekognitionService.js';

export async function enrollFace(userId, base64Image) {
  // If AWS credentials are configured, use real Rekognition
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
    return rekognitionService.enrollFace(userId, base64Image);
  }

  // Graceful fallback in local/development without AWS keys
  const mockFaceId = `face_${userId}_${Date.now()}`;
  return { faceId: mockFaceId, collectionId: 'local-dev-collection' };
}

export async function verifyFace(userId, base64Image) {
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
    return rekognitionService.verifyFace(userId, base64Image);
  }

  // Graceful fallback in local/development
  return {
    matched: true,
    score: 98.5,
    rekognitionUserId: userId,
  };
}
