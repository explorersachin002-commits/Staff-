import Attendance from '../models/Attendance.js';
import { validateGeofence } from './geofenceService.js';
import { verifyFace } from './faceService.js';
import { uploadSelfie } from './storageService.js';
import { getSettings } from './settingsService.js';

function todayString() {
  // Server-side date — never trust client date to prevent replay across days
  return new Date().toISOString().split('T')[0];
}

async function calculateStatus(checkInTime) {
  const settings = await getSettings();
  const [h, m] = settings.lateThreshold.split(':').map(Number);
  const lateThreshold = new Date(checkInTime);
  lateThreshold.setHours(h, m, 0, 0);
  return checkInTime > lateThreshold ? 'late' : 'present';
}

export async function performCheckIn({ userId, lat, lng, accuracy, isMockLocation, ip, selfieBase64, selfieUrl }) {
  // 1. Mock location rejection
  if (isMockLocation) {
    const err = new Error('Mock location detected. Check-in blocked.');
    err.status = 403;
    throw err;
  }

  // 2. GPS accuracy sanity check — reject very poor signals
  if (accuracy > 100) {
    const err = new Error(`GPS accuracy too low (${Math.round(accuracy)}m). Move to open sky and retry.`);
    err.status = 422;
    throw err;
  }

  // 3. Geofence validation (server-side, never trust client)
  const geo = await validateGeofence(userId, lat, lng);
  if (!geo.inside) {
    const err = new Error(geo.reason);
    err.status = 422;
    err.distance = geo.distance;
    throw err;
  }

  // Prevent duplicate check-in
  const date = todayString();
  let record = await Attendance.findOne({ userId, date });

  if (record?.checkIn) {
    const err = new Error('Already checked in today.');
    err.status = 409;
    throw err;
  }

  let finalSelfieKey = selfieUrl || null;
  let faceScore = null;

  const imagePayload = selfieBase64;
  if (imagePayload) {
    // 4. Upload selfie to S3
    const selfieKey = `selfies/${userId}/${date}_in_${Date.now()}.jpg`;
    await uploadSelfie(imagePayload, selfieKey);
    finalSelfieKey = selfieKey;

    // 5. Face verification
    const faceResult = await verifyFace(userId.toString(), imagePayload);
    if (!faceResult.matched || faceResult.score < 85) {
      const err = new Error(
        `Face verification failed (score: ${faceResult.score.toFixed(1)}%). Please ensure good lighting and try again.`
      );
      err.status = 422;
      throw err;
    }
    faceScore = faceResult.score;
  }

  const now = new Date();
  const checkInData = {
    timestamp: now,
    selfieUrl: finalSelfieKey,
    faceMatchScore: faceScore,
    livenessPassed: true,
    location: { type: 'Point', coordinates: [lng, lat] },
    accuracyMeters: accuracy,
    geofenceId: geo.geofence._id,
    distanceFromCenter: Math.round(geo.distance),
    isMockLocation: false,
    ipAddress: ip,
  };

  const calculatedStatus = await calculateStatus(now);

  if (record) {
    record.checkIn = checkInData;
    record.status = calculatedStatus;
    await record.save();
  } else {
    record = await Attendance.create({
      userId,
      date,
      checkIn: checkInData,
      status: calculatedStatus,
    });
  }

  return record;
}

export async function performCheckOut({ userId, lat, lng, accuracy, isMockLocation, ip, selfieBase64, selfieUrl }) {
  if (isMockLocation) {
    const err = new Error('Mock location detected. Check-out blocked.');
    err.status = 403;
    throw err;
  }

  if (accuracy > 100) {
    const err = new Error(`GPS accuracy too low (${Math.round(accuracy)}m).`);
    err.status = 422;
    throw err;
  }

  const geo = await validateGeofence(userId, lat, lng);
  if (!geo.inside) {
    const err = new Error(geo.reason);
    err.status = 422;
    err.distance = geo.distance;
    throw err;
  }

  const date = todayString();
  const record = await Attendance.findOne({ userId, date });

  if (!record?.checkIn) {
    const err = new Error('No check-in found for today. Check in first.');
    err.status = 409;
    throw err;
  }
  if (record.checkOut) {
    const err = new Error('Already checked out today.');
    err.status = 409;
    throw err;
  }

  let selfieKey = selfieUrl || null;
  let faceScore = null;

  if (selfieBase64) {
    // 4. Upload selfie to S3
    selfieKey = `selfies/${userId}/${date}_out_${Date.now()}.jpg`;
    await uploadSelfie(selfieBase64, selfieKey);

    // 5. Face verification
    const faceResult = await verifyFace(userId.toString(), selfieBase64);
    if (!faceResult.matched || faceResult.score < 85) {
      const err = new Error(
        `Face verification failed (score: ${faceResult.score.toFixed(1)}%). Please ensure good lighting and try again.`
      );
      err.status = 422;
      throw err;
    }
    faceScore = faceResult.score;
  }

  const now = new Date();
  record.checkOut = {
    timestamp: now,
    selfieUrl: selfieKey,
    faceMatchScore: faceScore,
    livenessPassed: true,
    location: { type: 'Point', coordinates: [lng, lat] },
    accuracyMeters: accuracy,
    geofenceId: geo.geofence._id,
    distanceFromCenter: Math.round(geo.distance),
    isMockLocation: false,
    ipAddress: ip,
  };

  // Calculate work hours
  const diffMs = now - record.checkIn.timestamp;
  record.workHours = Math.round((diffMs / 3600000) * 100) / 100;

  await record.save();
  return record;
}
