import { Expo } from 'expo-server-sdk';
import PushToken from '../models/PushToken.js';

const expo = new Expo();

export async function registerPushToken({ userId, token, platform, deviceId }) {
  if (!Expo.isExpoPushToken(token)) throw new Error('Invalid Expo push token');
  await PushToken.findOneAndUpdate(
    { token },
    { userId, token, platform, deviceId, lastSeenAt: new Date() },
    { upsert: true }
  );
}

export async function sendPushToUser(userId, { title, body, data = {} }) {
  const tokens = await PushToken.find({ userId });
  if (!tokens.length) return { sent: 0 };

  const messages = tokens.map((t) => ({
    to: t.token,
    sound: 'default',
    title,
    body,
    data,
    priority: 'high',
  }));

  const chunks = expo.chunkPushNotifications(messages);
  const tickets = [];
  for (const chunk of chunks) {
    try {
      const result = await expo.sendPushNotificationsAsync(chunk);
      tickets.push(...result);
    } catch (err) {
      console.error('Push send failed:', err);
    }
  }

  return { sent: tickets.length, tickets };
}

export async function sendPushToAll(userIds, payload) {
  return Promise.all(userIds.map((id) => sendPushToUser(id, payload)));
}
