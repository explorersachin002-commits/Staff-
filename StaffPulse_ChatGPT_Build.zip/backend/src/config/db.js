import mongoose from 'mongoose';
import { ENV } from './env.js';

export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(ENV.MONGO_URI);
    console.log(`[MongoDB] Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`[MongoDB] Connection error: ${error.message}`);
    // Allow server to run even if Mongo is offline in local dev mode
    console.warn('[MongoDB] Running in fallback mode. Ensure MongoDB is running for persistent storage.');
  }
};
