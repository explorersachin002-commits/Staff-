import mongoose from 'mongoose';

const settingsSchema = new mongoose.Schema(
  {
    _id: { type: String, default: 'global' }, // singleton
    workdayStart: { type: String, default: '09:00' },
    workdayEnd: { type: String, default: '18:00' },
    lateThreshold: { type: String, default: '09:30' },
    faceMatchThreshold: { type: Number, default: 85, min: 60, max: 100 },
    gpsAccuracyLimit: { type: Number, default: 100, min: 20, max: 500 },
    timezone: { type: String, default: 'Asia/Kolkata' },
    autoCheckoutAfterHours: { type: Number, default: 12 },
    reminderHours: { type: [Number], default: [9, 10, 11] }, // send reminder at these hours if not checked in
    weeklyReportDay: { type: Number, default: 1, min: 0, max: 6 }, // Monday
    weeklyReportHour: { type: Number, default: 9 },
    enablePushNotifications: { type: Boolean, default: true },
    enableEmailReports: { type: Boolean, default: true },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default mongoose.model('Settings', settingsSchema);
