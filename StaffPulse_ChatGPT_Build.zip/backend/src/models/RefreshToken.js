import mongoose from 'mongoose';

const refreshTokenSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    token: { type: String, required: true, unique: true, index: true },
    expiresAt: { type: Date, required: true, index: { expires: 0 } }, // TTL auto-delete
    isRevoked: { type: Boolean, default: false },
    replacedBy: { type: String, default: null }, // rotation chain
    createdByIp: { type: String },
  },
  { timestamps: true }
);

export default mongoose.model('RefreshToken', refreshTokenSchema);
