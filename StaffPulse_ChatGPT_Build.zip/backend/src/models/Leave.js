import mongoose from 'mongoose';

const leaveSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    employeeName: String,
    employeeCode: String,
    department: String,
    leaveType: {
      type: String,
      enum: ['CASUAL', 'SICK', 'ANNUAL', 'COMPENSATORY', 'UNPAID'],
      required: true
    },
    startDate: {
      type: String,
      required: true
    },
    endDate: {
      type: String,
      required: true
    },
    daysCount: {
      type: Number,
      default: 1
    },
    reason: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['PENDING', 'APPROVED', 'REJECTED'],
      default: 'PENDING'
    },
    reviewedBy: String,
    reviewNote: String
  },
  {
    timestamps: true
  }
);

export default mongoose.model('Leave', leaveSchema);
