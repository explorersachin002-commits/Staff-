import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
    },
    password: {
      type: String,
      required: true,
      minlength: 6,
      select: false, // never returned in queries by default
    },
    fullName: { type: String, required: true, trim: true },
    role: {
      type: String,
      enum: ['employee', 'admin'],
      default: 'employee',
      required: true,
    },
    department: { type: String, default: 'General' },
    employeeId: { type: String, unique: true, sparse: true },
    isActive: { type: Boolean, default: true },
    // Phase 2 & 3 device binding & biometrics
    faceEmbedding: { type: [mongoose.Schema.Types.Mixed], default: null, select: false },
    deviceFingerprint: { type: String, default: null },
    assignedGeofences: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Geofence' }],
    trustedDeviceId: { type: String, default: null },
    deviceBindingOtpHash: { type: String, default: null, select: false },
    deviceBindingOtpExpiry: { type: Date, default: null, select: false },
    deviceBindingNewDeviceId: { type: String, default: null, select: false },
    deviceBindingOtpAttempts: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

export default mongoose.model('User', userSchema);
