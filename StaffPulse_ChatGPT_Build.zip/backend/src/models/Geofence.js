import mongoose from 'mongoose';

const geofenceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    location: {
      type: { type: String, enum: ['Point'], default: 'Point', required: true },
      coordinates: {
        type: [Number], // [lng, lat]
        required: true,
        validate: (v) => v.length === 2,
      },
    },
    radiusMeters: {
      type: Number,
      required: true,
      min: 10,
      max: 1000,
      default: 100,
    },
    isActive: { type: Boolean, default: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

geofenceSchema.index({ location: '2dsphere' }); // for future $geoWithin queries

export default mongoose.model('Geofence', geofenceSchema);
