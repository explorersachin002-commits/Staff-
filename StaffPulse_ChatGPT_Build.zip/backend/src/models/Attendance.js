import mongoose from 'mongoose';

const checkSchema = new mongoose.Schema(
  {
    timestamp: { type: Date, required: true },
    selfieUrl: { type: String, default: null }, // local path in Phase 2; S3 in Phase 3
    faceMatchScore: { type: Number, default: null }, // populated in Phase 3
    livenessPassed: { type: Boolean, default: false },
    location: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number], required: true }, // [lng, lat]
    },
    accuracyMeters: { type: Number, required: true },
    geofenceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Geofence' },
    distanceFromCenter: { type: Number, required: true },
    isMockLocation: { type: Boolean, default: false },
    ipAddress: { type: String },
  },
  { _id: false }
);

const attendanceSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    date: { type: String, required: true, index: true }, // "YYYY-MM-DD"
    checkIn: { type: checkSchema, default: null },
    checkOut: { type: checkSchema, default: null },
    status: {
      type: String,
      enum: ['present', 'late', 'absent', 'half-day', 'leave'],
      default: 'present',
    },
    workHours: { type: Number, default: 0 },
  },
  { timestamps: true }
);

attendanceSchema.index({ userId: 1, date: 1 }, { unique: true });

export default mongoose.model('Attendance', attendanceSchema);
