import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import RefreshToken from '../models/RefreshToken.js';

export function signAccessToken(user) {
  return jwt.sign(
    {
      sub: user._id.toString(),
      role: user.role,
      email: user.email,
    },
    process.env.JWT_ACCESS_SECRET || 'dev_access_secret_key_987654321',
    { expiresIn: process.env.ACCESS_TOKEN_EXPIRY || '15m' }
  );
}

export function verifyAccessToken(token) {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET || 'dev_access_secret_key_987654321');
}

export async function issueRefreshToken(userId, ip) {
  const raw = crypto.randomBytes(48).toString('hex');
  const expiresAt = new Date(
    Date.now() + parseDuration(process.env.REFRESH_TOKEN_EXPIRY || '7d')
  );

  await RefreshToken.create({
    userId,
    token: raw,
    expiresAt,
    createdByIp: ip,
  });

  return raw;
}

export async function rotateRefreshToken(oldToken, ip) {
  const existing = await RefreshToken.findOne({ token: oldToken });

  if (!existing) throw new Error('Refresh token not found');
  if (existing.isRevoked) {
    // Token reuse detected — revoke entire chain for that user
    await RefreshToken.updateMany(
      { userId: existing.userId },
      { isRevoked: true }
    );
    throw new Error('Refresh token revoked. Please login again.');
  }
  if (existing.expiresAt < new Date()) throw new Error('Refresh token expired');

  // Issue new token
  const newRaw = crypto.randomBytes(48).toString('hex');
  const newExpiry = new Date(
    Date.now() + parseDuration(process.env.REFRESH_TOKEN_EXPIRY || '7d')
  );

  existing.isRevoked = true;
  existing.replacedBy = newRaw;
  await existing.save();

  await RefreshToken.create({
    userId: existing.userId,
    token: newRaw,
    expiresAt: newExpiry,
    createdByIp: ip,
  });

  return { newRaw, userId: existing.userId };
}

export async function revokeRefreshToken(token) {
  await RefreshToken.updateOne({ token }, { isRevoked: true });
}

function parseDuration(str) {
  const m = /^(\d+)([smhd])$/.exec(str);
  if (!m) return 7 * 24 * 60 * 60 * 1000;
  const n = parseInt(m[1], 10);
  const unit = { s: 1e3, m: 6e4, h: 36e5, d: 864e5 }[m[2]];
  return n * unit;
}
