import { Router } from 'express';
import {
  submitLeave, myLeaves, pendingLeaves, allLeaves, reviewLeave, cancelLeave,
} from '../controllers/leaveController.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleGuard.js';

const router = Router();
router.use(requireAuth);

router.post('/', submitLeave);
router.get('/me', myLeaves);
router.get('/my', myLeaves); // alias
router.post('/:id/cancel', cancelLeave);

router.get('/pending', requireRole('admin'), pendingLeaves);
router.get('/all', requireRole('admin'), allLeaves);
router.post('/:id/review', requireRole('admin'), reviewLeave);

export default router;
