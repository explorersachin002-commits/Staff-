import { Router } from 'express';
import {
  checkIn, checkOut, getToday, getHistory, getTeam, getStats,
} from '../controllers/attendanceController.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleGuard.js';

const router = Router();

router.use(requireAuth);

// Employee routes
router.post('/check-in', checkIn);
router.post('/check-out', checkOut);
router.get('/today', getToday);
router.get('/history', getHistory);

// Admin routes
router.get('/team', requireRole('admin'), getTeam);
router.get('/stats', requireRole('admin'), getStats);

export default router;
