import { Router } from 'express';
import { enrollFace } from '../services/faceService.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleGuard.js';
import User from '../models/User.js';
import AuditLog from '../models/AuditLog.js';
import { auditLog } from '../services/auditService.js';

const router = Router();
router.use(requireAuth);

// POST /api/employees/:id/enroll-face
router.post('/:id/enroll-face', requireRole('admin'), async (req, res) => {
  try {
    const { selfieBase64 } = req.body;
    if (!selfieBase64) return res.status(400).json({ error: 'selfieBase64 required' });

    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'Employee not found' });

    const result = await enrollFace(user._id.toString(), selfieBase64);

    user.faceEmbedding = [result.faceId]; // store reference
    await user.save();

    await auditLog({
      actorId: req.user.id,
      action: 'FACE_ENROLLED',
      targetType: 'Employee',
      targetId: user._id,
      newValue: { faceId: result.faceId },
      ipAddress: req.ip,
    });

    res.json({ success: true, faceId: result.faceId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/employees/audit/logs (admin only)
router.get('/audit/logs', requireRole('admin'), async (req, res) => {
  const { actorId, action, from, to, page = 1, limit = 50 } = req.query;
  const filter = {};
  if (actorId) filter.actorId = actorId;
  if (action) filter.action = action;
  if (from || to) {
    filter.timestamp = {};
    if (from) filter.timestamp.$gte = new Date(from);
    if (to) filter.timestamp.$lte = new Date(to);
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);
  const [logs, total] = await Promise.all([
    AuditLog.find(filter)
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('actorId', 'fullName email')
      .lean(),
    AuditLog.countDocuments(filter),
  ]);

  res.json({
    data: logs,
    pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) },
  });
});

// GET /api/employees - list employees (admin only)
router.get('/', requireRole('admin'), async (_, res) => {
  try {
    const employees = await User.find({ role: 'employee' }).select('-password').lean();
    res.json({ employees });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
