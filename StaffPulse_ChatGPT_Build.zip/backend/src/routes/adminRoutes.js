import { Router } from 'express';
import {
  listEmployees, getEmployee, createEmployee, updateEmployee, deleteEmployee,
  attendanceReport, dashboardTrends, liveLocations, getSettings, patchSettings,
} from '../controllers/adminController.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleGuard.js';
import AuditLog from '../models/AuditLog.js';

const router = Router();
router.use(requireAuth, requireRole('admin'));

router.get('/employees', listEmployees);
router.get('/employees/:id', getEmployee);
router.post('/employees', createEmployee);
router.put('/employees/:id', updateEmployee);
router.delete('/employees/:id', deleteEmployee);

router.get('/attendance/report', attendanceReport);
router.get('/reports/attendance', attendanceReport); // alias
router.get('/dashboard/trends', dashboardTrends);
router.get('/live/locations', liveLocations);
router.get('/live-locations', liveLocations); // alias
router.get('/settings', getSettings);
router.patch('/settings', patchSettings);
router.put('/settings', patchSettings);
router.post('/settings', patchSettings);

// Audit logs
router.get('/audit/logs', async (req, res) => {
  const { actorId, action, from, to, page = 1, limit = 50 } = req.query;
  const filter = {};
  if (actorId) filter.actorId = actorId;
  if (action) filter.action = action;
  if (from || to) {
    filter.timestamp = {};
    if (from) filter.timestamp.$gte = new Date(from);
    if (to) filter.timestamp.$lte = new Date(to);
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);
  const [logs, total] = await Promise.all([
    AuditLog.find(filter)
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .populate('actorId', 'fullName email')
      .lean(),
    AuditLog.countDocuments(filter),
  ]);

  res.json({
    data: logs,
    pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) },
  });
});

export default router;
