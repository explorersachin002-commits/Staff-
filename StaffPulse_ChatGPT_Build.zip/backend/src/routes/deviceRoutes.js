// backend/src/routes/deviceRoutes.js
import { Router } from 'express';
import { requestDeviceRebind, verifyDeviceRebind } from '../services/deviceBindingService.js';
import { registerPushToken } from '../services/pushService.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

// POST /api/devices/rebind/request
router.post('/rebind/request', async (req, res) => {
  try {
    const { newDeviceId } = req.body;
    if (!newDeviceId) return res.status(400).json({ error: 'newDeviceId required' });
    const result = await requestDeviceRebind(req.user.id, newDeviceId, req.ip);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/devices/rebind/verify
router.post('/rebind/verify', async (req, res) => {
  try {
    const { otp } = req.body;
    const result = await verifyDeviceRebind(req.user.id, otp);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/devices/push-token and POST /api/push/register
const handlePushToken = async (req, res) => {
  try {
    const { token, platform, deviceId } = req.body;
    if (!token || !platform || !deviceId) {
      return res.status(400).json({ error: 'token, platform, deviceId required' });
    }
    await registerPushToken({ userId: req.user.id, token, platform, deviceId });
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

router.post('/push-token', handlePushToken);
router.post('/register', handlePushToken);

export default router;
