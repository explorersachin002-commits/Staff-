import { Router } from 'express';
import Geofence from '../models/Geofence.js';
import { requireAuth } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleGuard.js';

const router = Router();
router.use(requireAuth);

// POST /api/geofences — create (admin only)
router.post('/', requireRole('admin'), async (req, res) => {
  const { name, latitude, longitude, radiusMeters } = req.body;
  if (!name || latitude == null || longitude == null) {
    return res.status(400).json({ error: 'name, latitude, longitude required' });
  }
  const gf = await Geofence.create({
    name,
    location: { type: 'Point', coordinates: [longitude, latitude] },
    radiusMeters: radiusMeters || 100,
    createdBy: req.user.id,
  });
  res.status(201).json(gf);
});

// GET /api/geofences — list (admin only)
router.get('/', requireRole('admin'), async (_, res) => {
  const geofences = await Geofence.find().sort({ createdAt: -1 });
  res.json({ geofences });
});

// DELETE /api/geofences/:id (admin only) — soft delete
router.delete('/:id', requireRole('admin'), async (req, res) => {
  await Geofence.findByIdAndUpdate(req.params.id, { isActive: false });
  res.json({ success: true });
});

export default router;
