import User from '../models/User.js';
import Attendance from '../models/Attendance.js';
import Geofence from '../models/Geofence.js';
import AuditLog from '../models/AuditLog.js';
import Settings from '../models/Settings.js';
import { getSettings as loadSettings, updateSettings } from '../services/settingsService.js';
import { auditLog } from '../services/auditService.js';
import bcrypt from 'bcryptjs';

// ─── Employee CRUD ───────────────────────────────────────────────
export async function listEmployees(req, res) {
  const { search = '', department, isActive, page = 1, limit = 50 } = req.query;
  const filter = { role: { $in: ['employee', 'admin'] } };

  if (search) {
    filter.$or = [
      { fullName: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
      { employeeId: { $regex: search, $options: 'i' } },
    ];
  }
  if (department) filter.department = department;
  if (isActive !== undefined) filter.isActive = isActive === 'true';

  const skip = (parseInt(page) - 1) * parseInt(limit);
  const [employees, total] = await Promise.all([
    User.find(filter).select('-password').skip(skip).limit(parseInt(limit)).lean(),
    User.countDocuments(filter),
  ]);

  res.json({
    data: employees.map((e) => ({
      ...e,
      hasFaceEnrolled: Array.isArray(e.faceEmbedding) && e.faceEmbedding.length > 0,
      hasDeviceBound: !!e.deviceFingerprint || !!e.trustedDeviceId,
    })),
    pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / limit) },
  });
}

export async function getEmployee(req, res) {
  const user = await User.findById(req.params.id).select('-password +faceEmbedding').lean();
  if (!user) return res.status(404).json({ error: 'Employee not found' });
  res.json({
    id: user._id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    department: user.department,
    hasFaceEnrolled: Array.isArray(user.faceEmbedding) && user.faceEmbedding.length > 0,
    hasDeviceBound: !!user.trustedDeviceId,
  });
}

export async function createEmployee(req, res) {
  try {
    const { email, password, fullName, department, employeeId, role = 'employee' } = req.body;
    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'email, password, fullName required' });
    }
    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'Email already exists' });

    const user = await User.create({
      email, password, fullName, department, employeeId, role,
    });

    await auditLog({
      actorId: req.user.id, action: 'EMPLOYEE_CREATED', targetType: 'Employee',
      targetId: user._id, newValue: { email, fullName, role }, ipAddress: req.ip,
    });

    res.status(201).json({
      id: user._id, email: user.email, fullName: user.fullName,
      role: user.role, department: user.department, employeeId: user.employeeId,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function updateEmployee(req, res) {
  try {
    const { fullName, department, employeeId, isActive, password } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'Employee not found' });

    const old = { fullName: user.fullName, department: user.department, isActive: user.isActive };

    if (fullName) user.fullName = fullName;
    if (department) user.department = department;
    if (employeeId) user.employeeId = employeeId;
    if (isActive !== undefined) user.isActive = isActive;
    if (password) user.password = password; // pre-save hook re-hashes

    await user.save();

    await auditLog({
      actorId: req.user.id, action: 'EMPLOYEE_UPDATED', targetType: 'Employee',
      targetId: user._id, oldValue: old,
      newValue: { fullName, department, isActive }, ipAddress: req.ip,
    });

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function deleteEmployee(req, res) {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ error: 'Employee not found' });

  user.isActive = false; // soft delete
  await user.save();

  await auditLog({
    actorId: req.user.id, action: 'EMPLOYEE_DEACTIVATED',
    targetType: 'Employee', targetId: user._id, ipAddress: req.ip,
  });

  res.json({ success: true });
}

// ─── Attendance reports ──────────────────────────────────────────
export async function attendanceReport(req, res) {
  const { from, to, department, status, page = 1, limit = 50, format } = req.query;
  const dateFilter = {};
  if (from) dateFilter.$gte = from;
  if (to) dateFilter.$lte = to;

  const filter = {};
  if (Object.keys(dateFilter).length) filter.date = dateFilter;
  if (status) filter.status = status;

  let userFilter = { role: 'employee' };
  if (department) userFilter.department = department;

  const employees = await User.find(userFilter).select('_id fullName email department employeeId').lean();
  const empMap = Object.fromEntries(employees.map((e) => [e._id.toString(), e]));
  filter.userId = { $in: employees.map((e) => e._id) };

  const skip = (parseInt(page) - 1) * parseInt(limit);
  const [records, total] = await Promise.all([
    Attendance.find(filter).sort({ date: -1 }).skip(skip).limit(parseInt(limit)).lean(),
    Attendance.countDocuments(filter),
  ]);

  const rows = records.map((r) => ({
    date: r.date,
    employeeId: empMap[r.userId.toString()]?.employeeId || '—',
    fullName: empMap[r.userId.toString()]?.fullName || 'Unknown',
    department: empMap[r.userId.toString()]?.department || '—',
    checkIn: r.checkIn?.timestamp || null,
    checkOut: r.checkOut?.timestamp || null,
    status: r.status,
    workHours: r.workHours,
    checkInDistance: r.checkIn?.distanceFromCenter,
    faceScore: r.checkIn?.faceMatchScore,
  }));

  // CSV export
  if (format === 'csv') {
    const header = 'Date,Employee ID,Name,Department,Check In,Check Out,Status,Work Hours\n';
    const body = rows.map((r) =>
      [r.date, r.employeeId, `"${r.fullName}"`, r.department,
       r.checkIn ? new Date(r.checkIn).toISOString() : '',
       r.checkOut ? new Date(r.checkOut).toISOString() : '',
       r.status, r.workHours].join(',')
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="attendance_${from || 'all'}_${to || 'all'}.csv"`);
    return res.send(header + body);
  }

  res.json({ data: rows, pagination: { total, page: parseInt(page), limit: parseInt(limit) } });
}

// ─── Trends & Analytics ──────────────────────────────────────────
export async function dashboardTrends(req, res) {
  const days = parseInt(req.query.days) || 7;
  const today = new Date();

  const dates = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    dates.push(d.toISOString().split('T')[0]);
  }

  const totalEmployees = await User.countDocuments({ role: 'employee', isActive: true });

  const trends = await Promise.all(
    dates.map(async (date) => {
      const records = await Attendance.find({ date }).lean();
      const present = records.filter((r) => r.status === 'present').length;
      const late = records.filter((r) => r.status === 'late').length;
      const checkedIn = records.filter((r) => r.checkIn).length;
      return {
        date,
        present, late, absent: totalEmployees - checkedIn,
        rate: totalEmployees > 0 ? Math.round((checkedIn / totalEmployees) * 100) : 0,
      };
    })
  );

  // Department breakdown for today
  const todayStr = today.toISOString().split('T')[0];
  const todayRecords = await Attendance.find({ date: todayStr }).populate('userId', 'department').lean();
  const byDept = {};
  for (const r of todayRecords) {
    const dept = r.userId?.department || 'Unknown';
    if (!byDept[dept]) byDept[dept] = { present: 0, late: 0, total: 0 };
    byDept[dept].total += 1;
    if (r.status === 'present') byDept[dept].present += 1;
    if (r.status === 'late') byDept[dept].late += 1;
  }

  res.json({ trends, departmentBreakdown: byDept, totalEmployees });
}

// ─── Live Locations ──────────────────────────────────────────────
export async function liveLocations(req, res) {
  const today = new Date().toISOString().split('T')[0];
  const records = await Attendance.find({
    date: today,
    'checkIn.timestamp': { $exists: true },
  })
    .populate('userId', 'fullName department employeeId')
    .lean();

  const points = records
    .filter((r) => r.checkIn?.location?.coordinates?.length === 2)
    .map((r) => ({
      userId: r.userId?._id,
      fullName: r.userId?.fullName,
      department: r.userId?.department,
      employeeId: r.userId?.employeeId,
      coordinates: r.checkIn.location.coordinates,
      checkInTime: r.checkIn.timestamp,
      status: r.status,
    }));

  res.json({ points, date: today });
}

// ─── Organization Settings ───────────────────────────────────────
export async function getSettings(req, res) {
  try {
    const s = await loadSettings();
    res.json(s.toObject ? s.toObject() : s);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function patchSettings(req, res) {
  try {
    const s = await loadSettings();
    const old = s.toObject ? s.toObject() : s;
    const updated = await updateSettings(req.body, req.user.id);

    await auditLog({
      actorId: req.user.id,
      action: 'SETTINGS_UPDATED',
      targetType: 'Settings',
      oldValue: { lateThreshold: old.lateThreshold, faceMatchThreshold: old.faceMatchThreshold },
      newValue: req.body,
      ipAddress: req.ip,
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export const updateSettingsHandler = patchSettings;
