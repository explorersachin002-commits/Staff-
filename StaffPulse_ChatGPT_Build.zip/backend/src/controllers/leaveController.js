import LeaveRequest from '../models/LeaveRequest.js';
import { createLeaveRequest, reviewLeaveRequest } from '../services/leaveService.js';
import { auditLog } from '../services/auditService.js';

export async function submitLeave(req, res) {
  try {
    const leave = await createLeaveRequest(req.user.id, req.body);
    await auditLog({
      actorId: req.user.id, action: 'LEAVE_REQUESTED',
      targetType: 'LeaveRequest', targetId: leave._id,
    });
    res.status(201).json(leave);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
}

export async function myLeaves(req, res) {
  const leaves = await LeaveRequest.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json({ leaves });
}

export async function pendingLeaves(req, res) {
  const leaves = await LeaveRequest.find({ status: 'pending' })
    .populate('userId', 'fullName email department employeeId')
    .sort({ createdAt: 1 });
  res.json({ leaves });
}

export async function allLeaves(req, res) {
  const { status, page = 1, limit = 50 } = req.query;
  const filter = status ? { status } : {};
  const skip = (parseInt(page) - 1) * parseInt(limit);

  const [leaves, total] = await Promise.all([
    LeaveRequest.find(filter)
      .populate('userId', 'fullName email department employeeId')
      .populate('reviewedBy', 'fullName')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit)),
    LeaveRequest.countDocuments(filter),
  ]);

  res.json({ leaves, total });
}

export async function reviewLeave(req, res) {
  try {
    const leave = await reviewLeaveRequest({
      leaveId: req.params.id,
      adminId: req.user.id,
      decision: req.body.decision, // 'approved' | 'rejected'
      note: req.body.note,
    });
    res.json(leave);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
}

export async function cancelLeave(req, res) {
  const leave = await LeaveRequest.findOne({ _id: req.params.id, userId: req.user.id });
  if (!leave) return res.status(404).json({ error: 'Not found' });
  if (leave.status !== 'pending') return res.status(409).json({ error: 'Cannot cancel reviewed leave' });

  leave.status = 'cancelled';
  await leave.save();
  res.json(leave);
}
