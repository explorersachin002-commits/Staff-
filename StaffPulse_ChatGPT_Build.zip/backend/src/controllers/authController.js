import User from '../models/User.js';
import {
  signAccessToken,
  issueRefreshToken,
  rotateRefreshToken,
  revokeRefreshToken,
} from '../utils/token.js';

// POST /api/auth/register
export async function register(req, res) {
  try {
    const { email, password, fullName, role, department, employeeId } = req.body;
    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Email, password, and fullName are required' });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ error: 'User already exists with this email' });
    }

    const user = await User.create({
      email,
      password,
      fullName: fullName.trim(),
      role: (role || 'employee').toLowerCase(),
      department: department || 'General',
      employeeId: employeeId || `EMP-${Math.floor(1000 + Math.random() * 9000)}`
    });

    const accessToken = signAccessToken(user);
    const refreshToken = await issueRefreshToken(user._id, req.ip);

    res.status(201).json({
      accessToken,
      refreshToken,
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        department: user.department,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /api/auth/login
export async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const user = await User.findOne({ email }).select('+password');
  if (!user || !user.isActive) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const ok = await user.comparePassword(password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const accessToken = signAccessToken(user);
  const refreshToken = await issueRefreshToken(user._id, req.ip);

  res.json({
    accessToken,
    refreshToken,
    user: {
      id: user._id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      department: user.department,
    },
  });
}

// POST /api/auth/refresh
export async function refresh(req, res) {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });

  try {
    const { newRaw, userId } = await rotateRefreshToken(refreshToken, req.ip);
    const user = await User.findById(userId);
    if (!user || !user.isActive) {
      return res.status(401).json({ error: 'User not found or inactive' });
    }

    res.json({
      accessToken: signAccessToken(user),
      refreshToken: newRaw,
    });
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
}

// POST /api/auth/logout
export async function logout(req, res) {
  const { refreshToken } = req.body;
  if (refreshToken) await revokeRefreshToken(refreshToken);
  res.json({ success: true });
}

// GET /api/auth/me
export async function me(req, res) {
  const user = await User.findById(req.user.id).select('+faceEmbedding');
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({
    id: user._id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    department: user.department,
    hasFaceEnrolled: Array.isArray(user.faceEmbedding) && user.faceEmbedding.length > 0,
    hasDeviceBound: !!user.trustedDeviceId,
  });
}

// Aliases for compatibility
export const refreshToken = refresh;
export const getMe = me;
