import { performCheckIn, performCheckOut } from '../services/attendanceService.js';
import { checkDeviceBinding } from '../services/deviceBindingService.js';
import Attendance from '../models/Attendance.js';
import User from '../models/User.js';

// POST /api/attendance/check-in
export async function checkIn(req, res) {
  try {
    const { latitude, longitude, accuracy, isMockLocation, selfieBase64, deviceId } = req.body;

    if (latitude == null || longitude == null || accuracy == null) {
      return res.status(400).json({ error: 'latitude, longitude, and accuracy are required' });
    }

    // Device binding check
    const deviceCheck = await checkDeviceBinding(req.user.id, deviceId || 'unknown');
    if (!deviceCheck.allowed) {
      return res.status(403).json({
        error: deviceCheck.reason,
        requiresOtp: deviceCheck.requiresOtp,
      });
    }

    const record = await performCheckIn({
      userId: req.user.id,
      lat: latitude,
      lng: longitude,
      accuracy,
      isMockLocation: !!isMockLocation,
      ip: req.ip,
      selfieBase64,
    });

    res.status(201).json({
      success: true,
      action: 'check-in',
      record: {
        id: record._id,
        date: record.date,
        status: record.status,
        timestamp: record.checkIn.timestamp,
        distanceFromCenter: record.checkIn.distanceFromCenter,
        faceMatchScore: record.checkIn.faceMatchScore,
      },
    });
  } catch (err) {
    res.status(err.status || 500).json({
      error: err.message,
      ...(err.distance != null && { distance: err.distance }),
    });
  }
}

// POST /api/attendance/check-out
export async function checkOut(req, res) {
  try {
    const { latitude, longitude, accuracy, isMockLocation, selfieBase64, deviceId } = req.body;

    if (latitude == null || longitude == null || accuracy == null) {
      return res.status(400).json({ error: 'latitude, longitude, and accuracy are required' });
    }

    // Device binding check
    const deviceCheck = await checkDeviceBinding(req.user.id, deviceId || 'unknown');
    if (!deviceCheck.allowed) {
      return res.status(403).json({
        error: deviceCheck.reason,
        requiresOtp: deviceCheck.requiresOtp,
      });
    }

    const record = await performCheckOut({
      userId: req.user.id,
      lat: latitude,
      lng: longitude,
      accuracy,
      isMockLocation: !!isMockLocation,
      ip: req.ip,
      selfieBase64,
    });

    res.json({
      success: true,
      action: 'check-out',
      record: {
        id: record._id,
        date: record.date,
        status: record.status,
        checkIn: record.checkIn.timestamp,
        checkOut: record.checkOut.timestamp,
        workHours: record.workHours,
        faceMatchScore: record.checkOut.faceMatchScore,
      },
    });
  } catch (err) {
    res.status(err.status || 500).json({
      error: err.message,
      ...(err.distance != null && { distance: err.distance }),
    });
  }
}

// GET /api/attendance/today
export async function getToday(req, res) {
  const date = new Date().toISOString().split('T')[0];
  const record = await Attendance.findOne({ userId: req.user.id, date });

  if (!record) {
    return res.json({ date, checkedIn: false, checkedOut: false, status: null });
  }

  res.json({
    date: record.date,
    checkedIn: !!record.checkIn,
    checkedOut: !!record.checkOut,
    status: record.status,
    checkIn: record.checkIn?.timestamp || null,
    checkOut: record.checkOut?.timestamp || null,
    workHours: record.workHours,
    checkInDistance: record.checkIn?.distanceFromCenter || null,
  });
}

// GET /api/attendance/history?limit=30
export async function getHistory(req, res) {
  const limit = Math.min(parseInt(req.query.limit) || 30, 100);
  const records = await Attendance.find({ userId: req.user.id })
    .sort({ date: -1 })
    .limit(limit)
    .lean();

  res.json({ records, count: records.length });
}

// GET /api/attendance/team?date=YYYY-MM-DD (admin only)
export async function getTeam(req, res) {
  const date = req.query.date || new Date().toISOString().split('T')[0];

  // Get all active employees
  const employees = await User.find({ role: 'employee', isActive: true })
    .select('_id fullName email department employeeId')
    .lean();

  // Get attendance for that date
  const records = await Attendance.find({ date }).lean();
  const byUser = Object.fromEntries(records.map((r) => [r.userId.toString(), r]));

  const rows = employees.map((emp) => {
    const rec = byUser[emp._id.toString()];
    return {
      employeeId: emp.employeeId,
      fullName: emp.fullName,
      email: emp.email,
      department: emp.department,
      checkIn: rec?.checkIn?.timestamp || null,
      checkOut: rec?.checkOut?.timestamp || null,
      status: rec?.status || 'absent',
      workHours: rec?.workHours || 0,
      checkInDistance: rec?.checkIn?.distanceFromCenter || null,
      checkInLocation: rec?.checkIn?.location?.coordinates || null,
    };
  });

  res.json({ date, rows, count: rows.length });
}

// GET /api/attendance/stats (admin only)
export async function getStats(req, res) {
  const date = req.query.date || new Date().toISOString().split('T')[0];

  const totalEmployees = await User.countDocuments({ role: 'employee', isActive: true });
  const records = await Attendance.find({ date }).lean();

  const present = records.filter((r) => r.status === 'present').length;
  const late = records.filter((r) => r.status === 'late').length;
  const checkedIn = records.filter((r) => r.checkIn).length;
  const absent = totalEmployees - checkedIn;

  res.json({
    date,
    totalEmployees,
    present,
    late,
    absent,
    attendanceRate: totalEmployees > 0 ? Math.round((checkedIn / totalEmployees) * 100) : 0,
  });
}
