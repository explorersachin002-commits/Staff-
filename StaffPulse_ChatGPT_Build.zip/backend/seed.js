import 'dotenv/config';
import mongoose from 'mongoose';
import User from './src/models/User.js';
import { connectDB } from './src/config/db.js';

await connectDB();

await User.deleteMany({}); // ⚠️ dev only

await User.create([
  {
    email: 'admin@company.com',
    password: 'Admin@123',
    fullName: 'Admin User',
    role: 'admin',
    department: 'HR',
    employeeId: 'ADM001',
  },
  {
    email: 'john@company.com',
    password: 'John@123',
    fullName: 'John Doe',
    role: 'employee',
    department: 'Engineering',
    employeeId: 'EMP001',
  },
]);

console.log('✅ Seeded admin + employee');

import Geofence from './src/models/Geofence.js';
await Geofence.deleteMany({});
await Geofence.create({
  name: 'Main Office',
  location: { type: 'Point', coordinates: [77.2090, 28.6139] },
  radiusMeters: 100,
  isActive: true,
});
console.log('✅ Seeded Main Office Geofence');

await mongoose.disconnect();
process.exit(0);
