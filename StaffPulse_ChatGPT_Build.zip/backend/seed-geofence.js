import 'dotenv/config';
import mongoose from 'mongoose';
import Geofence from './src/models/Geofence.js';
import { connectDB } from './src/config/db.js';

await connectDB();

await Geofence.deleteMany({});

// Replace with YOUR actual office location
await Geofence.create({
  name: 'Main Office',
  location: { type: 'Point', coordinates: [77.2090, 28.6139] }, // Delhi example
  radiusMeters: 100,
});

console.log('✅ Geofence seeded');
await mongoose.disconnect();
process.exit(0);
