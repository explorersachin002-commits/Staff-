# StaffPulse: Build APK with ChatGPT + GitHub Actions

This project ZIP includes a GitHub Actions workflow to attempt a cloud debug build.
The APK has not been built or verified yet. If the workflow fails, use its first error
from the Actions log to diagnose and fix the project.

## Steps

1. Create a **private** repository on https://github.com/new named `StaffPulse`.
2. Extract this ZIP on your computer.
3. Upload the extracted project files and folders to the repository root. Include `.github/workflows/build-apk.yml`.
4. Do not upload a real `.env` file, API keys, passwords, Firebase service-account files, or signing keys.
5. In GitHub, open the repository's **Actions** tab.
6. Choose **Build StaffPulse APK** and click **Run workflow** (or push files to `main` to trigger it).
7. Open the completed workflow run. If successful, download **StaffPulse-debug-apk** from Artifacts.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Transfer the APK to your Android phone and install it for testing.

## If the workflow fails

Open the failed job, expand **Build debug APK**, and copy the first meaningful error (usually the first `What went wrong` or `e:` compiler error) into ChatGPT. Do not paste API keys or secrets.

## Notes

- This workflow builds only the Android app module. It does not deploy the separate backend or admin console.
- Firebase/Gemini-dependent features may require proper configuration before runtime.
- This is a debug APK for testing, not a Play Store release.
