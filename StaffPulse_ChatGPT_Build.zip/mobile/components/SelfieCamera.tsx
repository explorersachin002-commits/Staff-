import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert,
} from 'react-native';
import { Camera, useCameraDevice, useCameraPermission } from 'react-native-vision-camera';
import { useFaceDetectorOutput } from 'react-native-vision-camera-face-detector';
import { useFaceAntiSpoofFrameOutput } from 'react-native-vision-camera-spoof-detector';

interface Props {
  onCapture: (base64: string) => void;
  onCancel: () => void;
}

export function SelfieCamera({ onCapture, onCancel }: Props) {
  const device = useCameraDevice('front');
  const { hasPermission, requestPermission } = useCameraPermission();
  const cameraRef = useRef<Camera>(null);

  const [faces, setFaces] = useState<any[]>([]);
  const [spoofResult, setSpoofResult] = useState<any>(null);
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    if (!hasPermission) requestPermission();
  }, [hasPermission]);

  const faceDetectorOutput = useFaceDetectorOutput({
    cameraFacing: 'front',
    autoMode: true,
    performanceMode: 'fast',
    trackingEnabled: true,
    onFacesDetected(detected: any[]) {
      setFaces(detected);
      if (detected.length === 0) setSpoofResult(null);
    },
  });

  const antiSpoofOutput = useFaceAntiSpoofFrameOutput({
    onResult(result: any) {
      setSpoofResult(result);
    },
  });

  // Liveness gate: exactly one face, spoof check passed
  const oneFace = faces.length === 1;
  const isLive = spoofResult?.isLive === true;
  const canCapture = oneFace && isLive;

  const handleCapture = async () => {
    if (!cameraRef.current || !canCapture) return;
    setCapturing(true);
    try {
      const photo = await cameraRef.current.takePhoto({ quality: 80 });
      const base64 = await readFileAsBase64(photo.path);
      onCapture(base64);
    } catch (e: any) {
      Alert.alert('Capture failed', e.message);
    } finally {
      setCapturing(false);
    }
  };

  if (!hasPermission) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Camera permission is required.</Text>
        <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!device) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#38BDF8" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Camera
        ref={cameraRef}
        style={StyleSheet.absoluteFill}
        device={device}
        isActive
        photo
        outputs={[faceDetectorOutput, antiSpoofOutput]}
      />

      {/* Face guide overlay */}
      <View pointerEvents="none" style={styles.overlay}>
        <View style={[
          styles.oval,
          canCapture ? styles.ovalGood : styles.ovalBad,
        ]} />
        <Text style={styles.hint}>
          {!oneFace
            ? 'Position your face in the oval'
            : !isLive
            ? 'Hold still — checking liveness…'
            : '✓ Ready. Tap to capture.'}
        </Text>
      </View>

      <View style={styles.controls}>
        <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.captureBtn, !canCapture && styles.captureDisabled]}
          onPress={handleCapture}
          disabled={!canCapture || capturing}
        >
          {capturing ? <ActivityIndicator color="#fff" /> : <View style={styles.captureInner} />}
        </TouchableOpacity>

        <View style={{ width: 60 }} />
      </View>
    </View>
  );
}

// Minimal base64 reader (install expo-file-system if not present)
async function readFileAsBase64(path: string): Promise<string> {
  const FileSystem = await import('expo-file-system');
  return FileSystem.readAsStringAsync(path, {
    encoding: FileSystem.EncodingType.Base64,
  });
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#000' },
  errorText: { color: '#fff', fontSize: 16, marginBottom: 16 },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  oval: {
    width: 240, height: 320, borderRadius: 160,
    borderWidth: 3, backgroundColor: 'transparent',
  },
  ovalGood: { borderColor: '#22C55E' },
  ovalBad: { borderColor: '#EAB308' },
  hint: {
    color: '#fff', marginTop: 20, fontSize: 14,
    backgroundColor: 'rgba(0,0,0,0.5)', paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 8, overflow: 'hidden',
  },
  controls: {
    position: 'absolute', bottom: 40, left: 0, right: 0,
    flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center',
  },
  cancelBtn: { padding: 12 },
  cancelText: { color: '#fff', fontSize: 15 },
  captureBtn: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: '#2563EB',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 4, borderColor: '#fff',
  },
  captureDisabled: { opacity: 0.4 },
  captureInner: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#fff' },
});
