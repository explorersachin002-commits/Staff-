import * as Location from 'expo-location';
import { Platform } from 'react-native';

export interface LocationResult {
  latitude: number;
  longitude: number;
  accuracy: number;
  isMockLocation: boolean;
}

export async function requestLocationPermission(): Promise<boolean> {
  const { status } = await Location.requestForegroundPermissionsAsync();
  return status === 'granted';
}

export async function getCurrentLocation(): Promise<LocationResult> {
  const { status } = await Location.getForegroundPermissionsAsync();
  if (status !== 'granted') {
    throw new Error('Location permission denied');
  }

  const loc = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.High,
    timeInterval: 5000,
  });

  // Android exposes mock location flag directly
  const isMock =
    Platform.OS === 'android' &&
    ((loc as any).mocked === true || (loc.coords as any).mocked === true);

  return {
    latitude: loc.coords.latitude,
    longitude: loc.coords.longitude,
    accuracy: loc.coords.accuracy ?? 999,
    isMockLocation: isMock,
  };
}
