import { api } from './api';

export interface Geofence {
  _id: string;
  name: string;
  location: {
    type: 'Point';
    coordinates: [number, number]; // [lng, lat]
  };
  radiusMeters: number;
  isActive: boolean;
}

export async function fetchGeofences(): Promise<Geofence[]> {
  try {
    const { data } = await api.get('/geofences');
    return data.geofences || [];
  } catch (err) {
    console.warn('Failed to fetch geofences', err);
    return [];
  }
}
