import * as TaskManager from 'expo-task-manager';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import { fetchGeofences } from './geofence';

const TASK_NAME = 'GEOFENCE_MONITOR';

TaskManager.defineTask(TASK_NAME, async ({ data, error }) => {
  if (error) return;
  const { locations } = data as any;
  if (!locations || locations.length === 0) return;
  const { latitude, longitude } = locations[0].coords;

  const fences = await fetchGeofences();
  for (const gf of fences) {
    const [gfLng, gfLat] = gf.location.coordinates;
    const dist = haversine(latitude, longitude, gfLat, gfLng);
    if (dist <= gf.radiusMeters) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: '📍 You have arrived',
          body: `Tap to check in at ${gf.name}`,
          data: { screen: 'check-in' },
        },
        trigger: null,
      });
      break;
    }
  }
});

export async function startGeofenceMonitoring() {
  const { status: fg } = await Location.requestForegroundPermissionsAsync();
  const { status: bg } = await Location.requestBackgroundPermissionsAsync();
  if (fg !== 'granted' || bg !== 'granted') return;

  await Location.startLocationUpdatesAsync(TASK_NAME, {
    accuracy: Location.Accuracy.Balanced,
    distanceInterval: 100, // check every 100m
    foregroundService: {
      notificationTitle: 'Attendance',
      notificationBody: 'Monitoring your location for check-in',
    },
  });
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
