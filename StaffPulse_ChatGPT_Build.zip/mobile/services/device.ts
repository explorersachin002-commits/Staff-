import * as Application from 'expo-application';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { api } from './api';

const DEVICE_KEY = 'deviceId';

export async function getDeviceId(): Promise<string> {
  let id = await SecureStore.getItemAsync(DEVICE_KEY);
  if (id) return id;

  // Build a stable device identifier
  const nativeId = Platform.select({
    android: Application.androidId,
    ios: await Application.getIosIdForVendorAsync(),
    default: 'unknown',
  }) || 'unknown';

  id = `${Platform.OS}-${nativeId}-${Date.now().toString(36)}`;
  await SecureStore.setItemAsync(DEVICE_KEY, id);
  return id;
}

export async function requestDeviceRebind(newDeviceId: string) {
  const { data } = await api.post('/devices/rebind/request', { newDeviceId });
  return data;
}

export async function verifyDeviceRebind(otp: string) {
  const { data } = await api.post('/devices/rebind/verify', { otp });
  return data;
}
