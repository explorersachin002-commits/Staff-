import { api } from './api';
import { getCurrentLocation } from './location';
import { getDeviceId } from './device';

export interface AttendanceResult {
  success: boolean;
  action: 'check-in' | 'check-out';
  record: any;
}

export async function doCheckIn(selfieBase64: string | null, deviceId?: string): Promise<AttendanceResult> {
  const [loc, resolvedDeviceId] = await Promise.all([
    getCurrentLocation(),
    deviceId ? Promise.resolve(deviceId) : getDeviceId(),
  ]);

  const { data } = await api.post('/attendance/check-in', {
    latitude: loc.latitude,
    longitude: loc.longitude,
    accuracy: loc.accuracy,
    isMockLocation: loc.isMockLocation,
    selfieBase64,
    deviceId: resolvedDeviceId,
  });

  return data;
}

export async function doCheckOut(selfieBase64: string | null, deviceId?: string): Promise<AttendanceResult> {
  const [loc, resolvedDeviceId] = await Promise.all([
    getCurrentLocation(),
    deviceId ? Promise.resolve(deviceId) : getDeviceId(),
  ]);

  const { data } = await api.post('/attendance/check-out', {
    latitude: loc.latitude,
    longitude: loc.longitude,
    accuracy: loc.accuracy,
    isMockLocation: loc.isMockLocation,
    selfieBase64,
    deviceId: resolvedDeviceId,
  });

  return data;
}

export async function fetchToday() {
  const { data } = await api.get('/attendance/today');
  return data;
}

export async function fetchHistory(limit = 30) {
  const { data } = await api.get(`/attendance/history?limit=${limit}`);
  return data;
}

export async function fetchTeam(date?: string) {
  const { data } = await api.get('/attendance/team', { params: { date } });
  return data;
}

export async function fetchStats(date?: string) {
  const { data } = await api.get('/attendance/stats', { params: { date } });
  return data;
}
