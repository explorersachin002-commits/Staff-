import { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator, Modal, TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { SelfieCamera } from '@/components/SelfieCamera';
import { doCheckIn } from '@/services/attendance';
import { getDeviceId, requestDeviceRebind, verifyDeviceRebind } from '@/services/device';

type Step = 'camera' | 'submitting';

export default function CheckInScreen() {
  const [step, setStep] = useState<Step>('camera');
  const [error, setError] = useState<string | null>(null);

  const [rebindModal, setRebindModal] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleCapture = async (base64: string) => {
    setStep('submitting');
    setError(null);
    try {
      const deviceId = await getDeviceId();
      const result = await doCheckIn(base64, deviceId);
      Alert.alert(
        '✓ Checked In',
        `Status: ${result.record.status}\nLocation verified.`,
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (e: any) {
      const err = e?.response?.data;
      if (err?.requiresOtp) {
        setRebindModal(true);
        setError(err.error);
      } else {
        setError(err?.error || e.message || 'Check-in failed');
      }
      setStep('camera');
    }
  };

  const handleSendOtp = async () => {
    setBusy(true);
    try {
      const deviceId = await getDeviceId();
      await requestDeviceRebind(deviceId);
      setOtpSent(true);
      Alert.alert('OTP Sent', 'A 6-digit code was sent to your registered email.');
    } catch (e: any) {
      Alert.alert('Failed to send OTP', e?.response?.data?.error || e.message);
    } finally {
      setBusy(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp.trim()) {
      Alert.alert('Invalid OTP', 'Please enter the 6-digit OTP code.');
      return;
    }
    setBusy(true);
    try {
      await verifyDeviceRebind(otp.trim());
      setRebindModal(false);
      setOtp('');
      setOtpSent(false);
      setError(null);
      Alert.alert('Device verified', 'Please tap capture again to check in.');
    } catch (e: any) {
      Alert.alert('Verification failed', e?.response?.data?.error || e.message);
    } finally {
      setBusy(false);
    }
  };

  if (step === 'submitting') {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#2563EB" />
        <Text style={styles.submittingText}>Verifying location, device, and selfie…</Text>
      </SafeAreaView>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <SelfieCamera onCapture={handleCapture} onCancel={() => router.back()} />

      {error && (
        <View style={styles.errorBanner}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity onPress={() => setError(null)}>
            <Text style={styles.dismissText}>Dismiss</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Device Rebinding OTP Modal */}
      <Modal
        visible={rebindModal}
        transparent
        animationType="slide"
        onRequestClose={() => setRebindModal(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>📱 New Device Detected</Text>
            <Text style={styles.modalSub}>
              This phone is not your registered device. Verify ownership with a one-time passcode (OTP) to bind this device.
            </Text>

            {!otpSent ? (
              <TouchableOpacity
                style={styles.primaryBtn}
                onPress={handleSendOtp}
                disabled={busy}
              >
                {busy ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.primaryBtnText}>Send OTP to Email</Text>
                )}
              </TouchableOpacity>
            ) : (
              <View style={styles.otpBlock}>
                <TextInput
                  style={styles.otpInput}
                  placeholder="Enter 6-digit OTP"
                  placeholderTextColor="#94A3B8"
                  value={otp}
                  onChangeText={setOtp}
                  keyboardType="number-pad"
                  maxLength={6}
                />
                <TouchableOpacity
                  style={styles.primaryBtn}
                  onPress={handleVerifyOtp}
                  disabled={busy}
                >
                  {busy ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={styles.primaryBtnText}>Verify & Rebind Device</Text>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.resendBtn}
                  onPress={handleSendOtp}
                  disabled={busy}
                >
                  <Text style={styles.resendText}>Resend OTP</Text>
                </TouchableOpacity>
              </View>
            )}

            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setRebindModal(false)}
            >
              <Text style={styles.closeBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  submittingText: { marginTop: 16, color: '#666' },
  errorBanner: {
    position: 'absolute', top: 60, left: 20, right: 20,
    backgroundColor: '#FEE2E2', padding: 14, borderRadius: 12,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  errorText: { color: '#991B1B', flex: 1, fontSize: 13 },
  dismissText: { color: '#991B1B', fontWeight: '700', marginLeft: 12 },
  modalBackdrop: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center', alignItems: 'center', padding: 24,
  },
  modalContent: {
    backgroundColor: '#fff', borderRadius: 20, padding: 24,
    width: '100%', maxWidth: 400,
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: '#0F172A', marginBottom: 8 },
  modalSub: { fontSize: 13, color: '#64748B', lineHeight: 18, marginBottom: 20 },
  otpBlock: { width: '100%' },
  otpInput: {
    borderWidth: 1.5, borderColor: '#CBD5E1', borderRadius: 12,
    paddingHorizontal: 16, paddingVertical: 14, fontSize: 18,
    textAlign: 'center', letterSpacing: 4, fontWeight: '700',
    color: '#0F172A', marginBottom: 14,
  },
  primaryBtn: {
    backgroundColor: '#2563EB', paddingVertical: 14, borderRadius: 12,
    alignItems: 'center', marginBottom: 10,
  },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  resendBtn: { alignItems: 'center', paddingVertical: 8 },
  resendText: { color: '#2563EB', fontSize: 13, fontWeight: '600' },
  closeBtn: { alignItems: 'center', marginTop: 10, paddingVertical: 8 },
  closeBtnText: { color: '#94A3B8', fontSize: 14, fontWeight: '600' },
});
