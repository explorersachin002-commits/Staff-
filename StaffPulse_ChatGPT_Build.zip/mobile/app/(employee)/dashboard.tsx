import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { fetchToday, doCheckOut } from '@/services/attendance';

export default function EmployeeDashboard() {
  const { user, signOut } = useAuth();
  const [today, setToday] = useState<any>(null);
  const [checkingOut, setCheckingOut] = useState(false);

  useFocusEffect(
    useCallback(() => {
      fetchToday().then(setToday).catch(() => {});
    }, [])
  );

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });

  const isCheckedIn = today?.checkedIn === true;
  const isCheckedOut = today?.checkedOut === true;

  const formatTime = (isoString?: string) => {
    if (!isoString) return '—';
    try {
      return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '—';
    }
  };

  const handleCheckOut = async () => {
    Alert.alert('Confirm Check-out', 'Are you ready to clock out for today?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Check Out',
        style: 'destructive',
        onPress: async () => {
          setCheckingOut(true);
          try {
            await doCheckOut(null);
            const updated = await fetchToday();
            setToday(updated);
            Alert.alert('✓ Checked Out', 'Your work hours have been recorded.');
          } catch (err: any) {
            Alert.alert('Check-out failed', err?.response?.data?.error || err.message);
          } finally {
            setCheckingOut(false);
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hello, {user?.fullName?.split(' ')[0]} 👋</Text>
            <Text style={styles.date}>{todayFormatted}</Text>
          </View>
          <TouchableOpacity onPress={signOut} style={styles.logoutBtn}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>

        {/* Status card */}
        <View style={styles.statusCard}>
          <Text style={styles.statusLabel}>Today's Status</Text>
          <View style={styles.statusBadge}>
            <Text style={styles.statusBadgeText}>
              {today?.checkedIn ? (today.checkedOut ? 'Checked Out' : 'Checked In') : 'Not Checked In'}
            </Text>
          </View>
          <Text style={styles.statusHint}>
            {isCheckedIn && today?.checkInDistance != null
              ? `Verified within geofence (${today.checkInDistance}m from center)`
              : 'Check-in available 9:00 AM – 6:00 PM'}
          </Text>
        </View>

        {/* Big Action button */}
        {!isCheckedIn ? (
          <TouchableOpacity
            style={styles.checkInBtn}
            activeOpacity={0.85}
            onPress={() => router.push('/(employee)/check-in')}
          >
            <Text style={styles.checkInIcon}>📸</Text>
            <Text style={styles.checkInText}>Check In</Text>
            <Text style={styles.checkInSub}>Selfie + Location required</Text>
          </TouchableOpacity>
        ) : !isCheckedOut ? (
          <TouchableOpacity
            style={[styles.checkInBtn, styles.checkOutBtn]}
            activeOpacity={0.85}
            onPress={handleCheckOut}
            disabled={checkingOut}
          >
            {checkingOut ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={styles.checkInIcon}>👋</Text>
                <Text style={styles.checkInText}>Check Out</Text>
                <Text style={styles.checkInSub}>Location verified clock-out</Text>
              </>
            )}
          </TouchableOpacity>
        ) : (
          <View style={styles.completedCard}>
            <Text style={styles.completedEmoji}>🎉</Text>
            <Text style={styles.completedText}>All Done for Today!</Text>
            <Text style={styles.completedSub}>Total Work: {today?.workHours || 0} hours</Text>
          </View>
        )}

        {/* Info cards */}
        <View style={styles.row}>
          <View style={styles.infoCard}>
            <Text style={styles.infoValue}>{formatTime(today?.checkIn)}</Text>
            <Text style={styles.infoLabel}>Check-in</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoValue}>{formatTime(today?.checkOut)}</Text>
            <Text style={styles.infoLabel}>Check-out</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoValue}>{today?.workHours ? `${today.workHours}h` : '0h'}</Text>
            <Text style={styles.infoLabel}>Worked</Text>
          </View>
        </View>

        {/* Week chart placeholder */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>This Week</Text>
          <View style={styles.chartRow}>
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
              <View key={i} style={styles.chartBarWrap}>
                <View
                  style={[
                    styles.chartBar,
                    { height: [60, 45, 70, isCheckedIn ? 50 : 0, 0, 0, 0][i] },
                  ]}
                />
                <Text style={styles.chartLabel}>{d}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity style={styles.actionRow}>
            <Text style={styles.actionText}>📋  My Attendance History</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionRow} onPress={() => router.push('/(employee)/leave')}>
            <Text style={styles.actionText}>🗓️  Request Leave & History</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionRow}>
            <Text style={styles.actionText}>👤  My Profile</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F5F7' },
  container: { padding: 20, paddingBottom: 40 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 20,
  },
  greeting: { fontSize: 22, fontWeight: '700', color: '#111' },
  date: { fontSize: 13, color: '#666', marginTop: 2 },
  logoutBtn: {
    paddingHorizontal: 12, paddingVertical: 6,
    borderRadius: 8, backgroundColor: '#FEE2E2',
  },
  logoutText: { color: '#DC2626', fontSize: 13, fontWeight: '600' },
  statusCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 20,
    marginBottom: 16, alignItems: 'center',
  },
  statusLabel: { fontSize: 13, color: '#666', marginBottom: 8 },
  statusBadge: {
    paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20,
  },
  badgePending: { backgroundColor: '#FEF3C7' },
  badgePresent: { backgroundColor: '#D1FAE5' },
  badgeCompleted: { backgroundColor: '#E0E7FF' },
  statusBadgeText: { fontWeight: '600', fontSize: 13 },
  badgeTextPending: { color: '#B45309' },
  badgeTextPresent: { color: '#047857' },
  badgeTextCompleted: { color: '#4338CA' },
  statusHint: { fontSize: 11, color: '#999', marginTop: 10 },
  checkInBtn: {
    backgroundColor: '#2563EB', borderRadius: 20, padding: 24,
    alignItems: 'center', marginBottom: 16,
    shadowColor: '#2563EB', shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 8 }, shadowRadius: 16, elevation: 8,
  },
  checkOutBtn: {
    backgroundColor: '#D97706', shadowColor: '#D97706',
  },
  checkInIcon: { fontSize: 40, marginBottom: 6 },
  checkInText: { color: '#fff', fontSize: 20, fontWeight: '700' },
  checkInSub: { color: '#DBEAFE', fontSize: 12, marginTop: 4 },
  completedCard: {
    backgroundColor: '#fff', borderRadius: 20, padding: 24,
    alignItems: 'center', marginBottom: 16, borderWidth: 1, borderColor: '#E2E8F0',
  },
  completedEmoji: { fontSize: 36, marginBottom: 4 },
  completedText: { fontSize: 18, fontWeight: '700', color: '#1E293B' },
  completedSub: { fontSize: 13, color: '#64748B', marginTop: 4 },
  row: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  infoCard: {
    flex: 1, backgroundColor: '#fff', borderRadius: 14,
    padding: 16, alignItems: 'center',
  },
  infoValue: { fontSize: 18, fontWeight: '700', color: '#111' },
  infoLabel: { fontSize: 11, color: '#666', marginTop: 4 },
  section: { marginBottom: 16 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#111', marginBottom: 10 },
  chartRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    backgroundColor: '#fff', borderRadius: 14, padding: 16, alignItems: 'flex-end',
  },
  chartBarWrap: { alignItems: 'center', flex: 1 },
  chartBar: {
    width: 20, borderRadius: 6, backgroundColor: '#2563EB',
    minHeight: 4, marginBottom: 6,
  },
  chartLabel: { fontSize: 11, color: '#666' },
  actionRow: {
    backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 8,
  },
  actionText: { fontSize: 14, color: '#111', fontWeight: '500' },
});
