import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  FlatList,
  Modal,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { api } from '@/services/api';

export default function LeaveScreen() {
  const [leaves, setLeaves] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [type, setType] = useState<'sick' | 'casual' | 'vacation' | 'unpaid' | 'other'>('casual');
  const [fromDate, setFromDate] = useState(new Date().toISOString().split('T')[0]);
  const [toDate, setToDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('');

  const loadLeaves = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/leaves/me');
      setLeaves(data.leaves || []);
    } catch (err: any) {
      console.warn('Failed to load leaves', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLeaves();
  }, []);

  const handleSubmit = async () => {
    if (!reason.trim()) {
      Alert.alert('Required', 'Please provide a reason for your leave.');
      return;
    }
    setSubmitting(true);
    try {
      await api.post('/leaves', {
        type,
        fromDate,
        toDate,
        reason,
      });
      setModalVisible(false);
      setReason('');
      loadLeaves();
      Alert.alert('Success', 'Your leave request has been submitted.');
    } catch (err: any) {
      Alert.alert('Error', err.response?.data?.error || 'Failed to submit leave request');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async (id: string) => {
    Alert.alert('Cancel Request', 'Are you sure you want to cancel this pending leave?', [
      { text: 'No', style: 'cancel' },
      {
        text: 'Yes, Cancel',
        style: 'destructive',
        onPress: async () => {
          try {
            await api.post(`/leaves/${id}/cancel`);
            loadLeaves();
          } catch (err: any) {
            Alert.alert('Error', err.response?.data?.error || 'Failed to cancel');
          }
        },
      },
    ]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return { bg: '#DCFCE7', text: '#15803D' };
      case 'rejected':
        return { bg: '#FEE2E2', text: '#B91C1C' };
      case 'cancelled':
        return { bg: '#F1F5F9', text: '#64748B' };
      default:
        return { bg: '#FEF3C7', text: '#B45309' };
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Leave Management</Text>
        <TouchableOpacity onPress={() => setModalVisible(true)} style={styles.addBtn}>
          <Text style={styles.addText}>+ Apply</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#2563EB" />
        </View>
      ) : (
        <FlatList
          data={leaves}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => {
            const badge = getStatusColor(item.status);
            return (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardType}>{item.type.toUpperCase()}</Text>
                  <View style={[styles.badge, { backgroundColor: badge.bg }]}>
                    <Text style={[styles.badgeText, { color: badge.text }]}>
                      {item.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <Text style={styles.dateRange}>
                  📅 {item.fromDate} → {item.toDate} ({item.days} day{item.days > 1 ? 's' : ''})
                </Text>
                <Text style={styles.reason} numberOfLines={2}>
                  "{item.reason}"
                </Text>

                {item.reviewNote && (
                  <Text style={styles.reviewNote}>
                    Reviewer Note: {item.reviewNote}
                  </Text>
                )}

                {item.status === 'pending' && (
                  <TouchableOpacity
                    onPress={() => handleCancel(item._id)}
                    style={styles.cancelBtn}
                  >
                    <Text style={styles.cancelBtnText}>Cancel Request</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyEmoji}>🏖️</Text>
              <Text style={styles.emptyTitle}>No Leave Requests</Text>
              <Text style={styles.emptySub}>Apply for time off using the button above.</Text>
            </View>
          }
        />
      )}

      {/* Modal for Leave Request */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Apply for Leave</Text>

            <Text style={styles.label}>Leave Type</Text>
            <View style={styles.typeRow}>
              {(['casual', 'sick', 'vacation', 'unpaid'] as const).map((t) => (
                <TouchableOpacity
                  key={t}
                  onPress={() => setType(t)}
                  style={[styles.typeChip, type === t && styles.typeChipActive]}
                >
                  <Text
                    style={[styles.typeChipText, type === t && styles.typeChipTextActive]}
                  >
                    {t.charAt(0).toUpperCase() + t.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.label}>From Date (YYYY-MM-DD)</Text>
            <TextInput
              value={fromDate}
              onChangeText={setFromDate}
              style={styles.input}
              placeholder="YYYY-MM-DD"
            />

            <Text style={styles.label}>To Date (YYYY-MM-DD)</Text>
            <TextInput
              value={toDate}
              onChangeText={setToDate}
              style={styles.input}
              placeholder="YYYY-MM-DD"
            />

            <Text style={styles.label}>Reason</Text>
            <TextInput
              value={reason}
              onChangeText={setReason}
              style={[styles.input, styles.textArea]}
              placeholder="Explain the purpose of your leave request…"
              multiline
            />

            <View style={styles.modalActions}>
              <TouchableOpacity
                onPress={() => setModalVisible(false)}
                style={styles.modalCancel}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSubmit}
                disabled={submitting}
                style={[styles.modalSubmit, submitting && { opacity: 0.6 }]}
              >
                <Text style={styles.modalSubmitText}>
                  {submitting ? 'Submitting…' : 'Submit'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F8FAFC' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  backBtn: { paddingVertical: 4 },
  backText: { color: '#2563EB', fontSize: 15, fontWeight: '600' },
  title: { fontSize: 17, fontWeight: '700', color: '#0F172A' },
  addBtn: {
    backgroundColor: '#2563EB',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  addText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardType: { fontSize: 13, fontWeight: '700', color: '#0F172A' },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  badgeText: { fontSize: 10, fontWeight: '700' },
  dateRange: { fontSize: 13, color: '#334155', fontWeight: '500', marginBottom: 6 },
  reason: { fontSize: 12, color: '#64748B', fontStyle: 'italic', marginBottom: 8 },
  reviewNote: { fontSize: 11, color: '#0284C7', marginBottom: 8 },
  cancelBtn: { alignSelf: 'flex-start', marginTop: 4 },
  cancelBtnText: { color: '#EF4444', fontSize: 12, fontWeight: '600' },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyEmoji: { fontSize: 44, marginBottom: 12 },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: '#0F172A' },
  emptySub: { fontSize: 13, color: '#64748B', marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#0F172A', marginBottom: 16 },
  label: { fontSize: 12, fontWeight: '600', color: '#475569', marginBottom: 6 },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 14, flexWrap: 'wrap' },
  typeChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
  },
  typeChipActive: { backgroundColor: '#2563EB' },
  typeChipText: { fontSize: 12, fontWeight: '600', color: '#475569' },
  typeChipTextActive: { color: '#fff' },
  input: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 10,
    padding: 10,
    fontSize: 14,
    marginBottom: 14,
    color: '#0F172A',
  },
  textArea: { height: 70, textAlignVertical: 'top' },
  modalActions: { flexDirection: 'row', gap: 10, marginTop: 8 },
  modalCancel: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
  },
  modalCancelText: { color: '#475569', fontSize: 14, fontWeight: '600' },
  modalSubmit: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: '#2563EB',
    alignItems: 'center',
  },
  modalSubmitText: { color: '#fff', fontSize: 14, fontWeight: '600' },
});
