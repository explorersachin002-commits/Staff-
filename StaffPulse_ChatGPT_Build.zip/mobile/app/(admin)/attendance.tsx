import { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { fetchTeam, fetchStats } from '@/services/attendance';

export default function AdminAttendance() {
  const [rows, setRows] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const [team, s] = await Promise.all([fetchTeam(), fetchStats()]);
      setRows(team.rows);
      setStats(s);
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(); }, []);

  if (loading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#2563EB" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.back}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Team Attendance</Text>
      </View>

      {stats && (
        <View style={styles.kpiRow}>
          <KPI label="Total" value={stats.totalEmployees} />
          <KPI label="Present" value={stats.present} color="#22C55E" />
          <KPI label="Late" value={stats.late} color="#EAB308" />
          <KPI label="Absent" value={stats.absent} color="#EF4444" />
          <KPI label="Rate" value={`${stats.attendanceRate}%`} color="#2563EB" />
        </View>
      )}

      <FlatList
        data={rows}
        keyExtractor={(item) => item.employeeId || item.email}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} />
        }
        renderItem={({ item }) => <Row row={item} />}
        ListEmptyComponent={<Text style={styles.empty}>No employees found.</Text>}
      />
    </SafeAreaView>
  );
}

function KPI({ label, value, color = '#111' }: any) {
  return (
    <View style={styles.kpi}>
      <Text style={[styles.kpiValue, { color }]}>{value}</Text>
      <Text style={styles.kpiLabel}>{label}</Text>
    </View>
  );
}

function Row({ row }: { row: any }) {
  const statusColor = ({
    present: '#22C55E', late: '#EAB308', absent: '#EF4444',
    'half-day': '#3B82F6', leave: '#8B5CF6',
  } as Record<string, string>)[row.status] || '#999';

  const inTime = row.checkIn ? new Date(row.checkIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';
  const outTime = row.checkOut ? new Date(row.checkOut).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <View style={styles.row}>
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>{row.fullName}</Text>
        <Text style={styles.dept}>{row.department} · {row.employeeId}</Text>
      </View>
      <View style={styles.times}>
        <Text style={styles.timeText}>In {inTime}</Text>
        <Text style={styles.timeText}>Out {outTime}</Text>
      </View>
      <View style={[styles.statusChip, { backgroundColor: statusColor + '22' }]}>
        <Text style={[styles.statusText, { color: statusColor }]}>{row.status.toUpperCase()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F5F7' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  back: { color: '#2563EB', fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700' },
  kpiRow: { flexDirection: 'row', paddingHorizontal: 12, gap: 8, marginBottom: 8 },
  kpi: {
    flex: 1, backgroundColor: '#fff', borderRadius: 12, padding: 10, alignItems: 'center',
  },
  kpiValue: { fontSize: 16, fontWeight: '700' },
  kpiLabel: { fontSize: 10, color: '#666', marginTop: 2 },
  row: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    marginHorizontal: 12, marginBottom: 6, borderRadius: 12, padding: 14,
  },
  name: { fontSize: 14, fontWeight: '600', color: '#111' },
  dept: { fontSize: 11, color: '#666', marginTop: 2 },
  times: { alignItems: 'flex-end', marginRight: 12 },
  timeText: { fontSize: 11, color: '#444' },
  statusChip: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  statusText: { fontSize: 10, fontWeight: '700' },
  empty: { textAlign: 'center', marginTop: 40, color: '#999' },
});
