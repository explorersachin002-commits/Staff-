import { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { api } from '@/services/api';

export default function EmployeesScreen() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/employees?limit=100')
      .then((r) => setRows(r.data.data || []))
      .catch((err) => console.warn('Failed to fetch employees', err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#2563EB" /></SafeAreaView>;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Employees ({rows.length})</Text>
      </View>
      <FlatList
        data={rows}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.fullName}</Text>
              <Text style={styles.sub}>{item.email} · {item.department}</Text>
            </View>
            <View style={styles.badges}>
              {item.hasFaceEnrolled && <Text style={styles.badge} title="Face Enrolled">📸</Text>}
              {item.hasDeviceBound && <Text style={styles.badge} title="Device Bound">📱</Text>}
              {!item.isActive && <Text style={styles.badgeInactive}>INACTIVE</Text>}
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No employees found.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F5F7' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16,
    paddingVertical: 12, gap: 12, backgroundColor: '#fff', borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0', marginBottom: 8,
  },
  backBtn: { paddingVertical: 4 },
  backText: { color: '#2563EB', fontSize: 15, fontWeight: '600' },
  title: { fontSize: 18, fontWeight: '700', color: '#0F172A' },
  row: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    marginHorizontal: 12, marginBottom: 8, borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: '#E2E8F0',
  },
  name: { fontWeight: '600', color: '#111', fontSize: 14 },
  sub: { fontSize: 11, color: '#666', marginTop: 2 },
  badges: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  badge: { fontSize: 16 },
  badgeInactive: { fontSize: 9, color: '#EF4444', fontWeight: '700' },
  empty: { textAlign: 'center', marginTop: 40, color: '#94A3B8' },
});
