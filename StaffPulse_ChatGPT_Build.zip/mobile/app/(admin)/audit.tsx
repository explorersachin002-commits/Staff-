import { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { api } from '@/services/api';

export default function AuditLogScreen() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/employees/audit/logs?limit=100')
      .then((r) => setLogs(r.data.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#2563EB" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Audit Log</Text>
      </View>
      <FlatList
        data={logs}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={styles.rowHeader}>
              <Text style={styles.action}>{item.action}</Text>
              <Text style={styles.time}>{new Date(item.timestamp).toLocaleString()}</Text>
            </View>
            <Text style={styles.actor}>Actor: {item.actorId?.fullName || 'System'} ({item.actorId?.email || 'N/A'})</Text>
            {item.ipAddress && <Text style={styles.meta}>IP: {item.ipAddress}</Text>}
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No audit entries.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F5F7' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16,
    paddingVertical: 14, gap: 12, backgroundColor: '#fff', borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0', marginBottom: 8,
  },
  backBtn: { paddingVertical: 4 },
  backText: { color: '#2563EB', fontSize: 15, fontWeight: '600' },
  title: { fontSize: 18, fontWeight: '700', color: '#0F172A' },
  row: {
    backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8,
    borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#E2E8F0',
  },
  rowHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  action: { fontWeight: '700', color: '#1E293B', fontSize: 14 },
  actor: { color: '#475569', fontSize: 12, marginTop: 2 },
  meta: { color: '#94A3B8', fontSize: 11, marginTop: 2 },
  time: { color: '#64748B', fontSize: 11 },
  empty: { textAlign: 'center', marginTop: 40, color: '#94A3B8' },
});
