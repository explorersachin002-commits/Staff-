import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { fetchStats } from '@/services/attendance';

export default function AdminDashboard() {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetchStats().then(setStats).catch(() => {});
  }, []);

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Admin Console</Text>
          <TouchableOpacity onPress={signOut} style={styles.logoutBtn}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.welcome}>Welcome, {user?.fullName}</Text>

        <View style={styles.grid}>
          {[
            { label: 'Employees', value: stats?.totalEmployees ?? '—', icon: '👥' },
            { label: 'Present Today', value: stats?.present ?? '—', icon: '✅' },
            { label: 'Absent', value: stats?.absent ?? '—', icon: '❌' },
            { label: 'Late', value: stats?.late ?? '—', icon: '⏰' },
          ].map((k) => (
            <TouchableOpacity
              key={k.label}
              style={styles.card}
              activeOpacity={0.85}
              onPress={() => router.push('/(admin)/attendance')}
            >
              <Text style={styles.cardIcon}>{k.icon}</Text>
              <Text style={styles.cardValue}>{k.value}</Text>
              <Text style={styles.cardLabel}>{k.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.navBtn} onPress={() => router.push('/(admin)/attendance')}>
          <Text style={styles.navBtnText}>📋  Team Attendance</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navBtn} onPress={() => router.push('/(admin)/employees')}>
          <Text style={styles.navBtnText}>👥  Manage Employees</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navBtn} onPress={() => router.push('/(admin)/audit')}>
          <Text style={styles.navBtnText}>🔒  Audit Log</Text>
        </TouchableOpacity>

        <Text style={styles.note}>
          Tap any card or the buttons above to view live employee attendance & security events.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F5F7' },
  container: { flex: 1, padding: 20 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  title: { fontSize: 24, fontWeight: '700', color: '#111' },
  logoutBtn: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8,
    backgroundColor: '#FEE2E2',
  },
  logoutText: { color: '#DC2626', fontWeight: '600', fontSize: 13 },
  welcome: { fontSize: 14, color: '#666', marginTop: 4, marginBottom: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  card: {
    width: '47%', backgroundColor: '#fff', borderRadius: 16,
    padding: 18, alignItems: 'center',
  },
  cardIcon: { fontSize: 28, marginBottom: 6 },
  cardValue: { fontSize: 22, fontWeight: '700', color: '#111' },
  cardLabel: { fontSize: 12, color: '#666', marginTop: 2 },
  navBtn: {
    backgroundColor: '#2563EB', borderRadius: 14, padding: 16,
    alignItems: 'center', marginTop: 10,
  },
  navBtnText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  secondaryNavBtn: {
    backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#CBD5E1', marginTop: 10,
  },
  secondaryNavBtnText: { color: '#1E293B' },
  note: { fontSize: 12, color: '#999', marginTop: 20, textAlign: 'center' },
});
