import React from 'react';
import { Stack } from 'expo-router';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { View, ActivityIndicator } from 'react-native';

// Fallback safe definition for Stack.Protected if not natively provided by installed expo-router
if (!(Stack as any).Protected) {
  (Stack as any).Protected = function Protected({
    guard,
    children
  }: {
    guard: boolean;
    children: React.ReactNode;
  }) {
    return guard ? <>{children}</> : null;
  };
}

import * as Notifications from 'expo-notifications';
import { router } from 'expo-router';
import { useEffect } from 'react';
import { registerForPushNotifications } from '@/services/notifications';

function RootNavigator() {
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (user) {
      registerForPushNotifications().catch(() => {});
    }

    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const screen = response.notification.request.content.data?.screen;
      if (screen === 'check-in') router.push('/(employee)/check-in');
      if (screen === 'leave') router.push('/(employee)/leave');
    });
    return () => sub.remove();
  }, [user]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      {/* Public routes — only when NOT logged in */}
      <Stack.Protected guard={!user}>
        <Stack.Screen name="(auth)" />
      </Stack.Protected>

      {/* Employee routes */}
      <Stack.Protected guard={user?.role === 'employee'}>
        <Stack.Screen name="(employee)" />
      </Stack.Protected>

      {/* Admin routes */}
      <Stack.Protected guard={user?.role === 'admin'}>
        <Stack.Screen name="(admin)" />
      </Stack.Protected>
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <AuthProvider>
      <RootNavigator />
    </AuthProvider>
  );
}
